// ============================================================
//  VANGUARD MD — index.js
//  Startup | Pairing | Loader
// ============================================================

const {
  makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
} = require('@whiskeysockets/baileys')

const readline = require('readline')
const pino = require('pino')
const path = require('path')
const fs = require('fs')
const chalk = require('chalk')
const config = require('./config')
const defaults = require('./defaults')
const logger = require('./lib/logger')
const { startCleanupScheduler } = require('./lib/messageStore')

// ── Auto-load all command plugins ────────────────────────────
const commandsPath = path.join(__dirname, 'commands')
const commandFiles = fs.readdirSync(commandsPath).filter(f => f.endsWith('.js'))

const commands = {}
for (const file of commandFiles) {
  try {
    const plugin = require(path.join(commandsPath, file))
    const name = path.basename(file, '.js')
    commands[name] = plugin
    logger.info(`✅ Loaded command: ${name}`)
  } catch (err) {
    logger.error(`❌ Failed to load command: ${file} — ${err.message}`)
  }
}

// ── Readline for pairing ─────────────────────────────────────
const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
const question = (text) => new Promise(resolve => rl.question(text, resolve))

// ── Session directory ─────────────────────────────────────────
const SESSION_DIR = path.join(__dirname, 'session')
if (!fs.existsSync(SESSION_DIR)) fs.mkdirSync(SESSION_DIR, { recursive: true })

const CONFIG_FILE = path.join(__dirname, 'data', 'config.json')

// ── Detect if session is GENUINELY active ────────────────────
// A bare creds.json upload doesn't count — we check for
// activity files that Baileys only creates during real use
const hasExistingSession = () => {
  try {
    const files = fs.readdirSync(SESSION_DIR)

    // Must have creds.json at minimum
    if (!files.includes('creds.json')) return false

    // These files are ONLY created by Baileys during actual connection activity
    const activityFiles = files.filter(f =>
      f.startsWith('app-state-sync-key-') ||
      f.startsWith('app-state-sync-version-') ||
      f.startsWith('sender-key-') ||
      f.startsWith('session-') ||
      f.startsWith('pre-key-')
    )

    // Genuine session = creds.json + at least 2 Baileys activity files
    const isGenuine = activityFiles.length >= 2

    if (!isGenuine) {
      logger.warn('⚠️  creds.json found but session activity files missing — treating as fresh install')
    }

    return isGenuine

  } catch { return false }
}

// ── Detect if config has been saved before ───────────────────
const hasExistingConfig = () => {
  try {
    if (!fs.existsSync(CONFIG_FILE)) return false
    const saved = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'))
    return Object.keys(saved).length > 0
  } catch { return false }
}

// ── Build startup message ─────────────────────────────────────
const buildStartupMessage = (isReturning) => {
  const prefix   = config.prefix      || defaults.prefix      || '.'
  const mode     = config.mode        || defaults.mode        || 'public'
  const owner    = config.ownerNumber || defaults.ownerNumber || 'Not set'
  const botName  = config.botName     || defaults.botName     || 'VANGUARD MD'
  const cmdCount = Object.keys(commands).length
  const time     = new Date().toLocaleString('en-KE', { timeZone: 'Africa/Nairobi' })

  if (isReturning) {
    // ── Returning bot — show full live stats ──────────────────
    return (
      `━━━━━━━━━━━━━━━━━━━━━\n` +
      `🤖 *${botName} ONLINE*\n` +
      `━━━━━━━━━━━━━━━━━━━━━\n` +
      `✅ Bot has started successfully\n` +
      `👑 Owner: *+${owner}*\n` +
      `📡 Mode: *${mode.toUpperCase()}*\n` +
      `🔑 Prefix: *${prefix}*\n` +
      `⚡ Commands: *${cmdCount} loaded*\n` +
      `👁️ Auto View Status: *${config.autoViewStatus  ?? defaults.autoViewStatus  ? 'ON' : 'OFF'}*\n` +
      `🗑️ Anti Delete: *${config.antidelete           ?? defaults.antidelete       ? 'ON' : 'OFF'}*\n` +
      `✏️ Anti Edit: *${config.antiedit               ?? defaults.antiedit         ? 'ON' : 'OFF'}*\n` +
      `📵 Anti Call: *${config.anticall               ?? defaults.anticall         ? 'ON' : 'OFF'}*\n` +
      `🤖 Chatbot: *${config.chatbot                  ?? defaults.chatbot          ? 'ON' : 'OFF'}*\n` +
      `⏱️ Time: ${time}\n` +
      `━━━━━━━━━━━━━━━━━━━━━\n` +
      `> *Vanguard is on Fire* 🔥`
    )
  } else {
    // ── Fresh bot — welcome + default settings + tips ─────────
    return (
      `━━━━━━━━━━━━━━━━━━━━━\n` +
      `🤖 *${botName} ONLINE*\n` +
      `━━━━━━━━━━━━━━━━━━━━━\n` +
      `🎉 *Welcome! First time setup complete*\n\n` +
      `📋 *Default Settings:*\n` +
      `📡 Mode: *${mode.toUpperCase()}*\n` +
      `🔑 Prefix: *${prefix}*\n` +
      `⚡ Commands: *${cmdCount} loaded*\n\n` +
      `💡 *Tip: Customize with these commands:*\n` +
      `  ${prefix}setprefix — change prefix\n` +
      `  ${prefix}public / ${prefix}private — change mode\n` +
      `  ${prefix}anticall on/off — toggle call block\n` +
      `  ${prefix}autoviewstatus on/off — toggle status view\n` +
      `  ${prefix}antidelete on/off — toggle delete alerts\n` +
      `  ${prefix}chatbot on/off — toggle chatbot\n\n` +
      `⏱️ Time: ${time}\n` +
      `━━━━━━━━━━━━━━━━━━━━━\n` +
      `> *Vanguard is on Fire* 🔥`
    )
  }
}

// ── Main connection function ──────────────────────────────────
async function startVanguard() {
  const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR)
  const { version } = await fetchLatestBaileysVersion()

  // ── Session intelligence check ────────────────────────────
  const isReturning = hasExistingSession() && hasExistingConfig()

  if (isReturning) {
    logger.success('🔄 Genuine session detected — resuming quietly...')
  } else {
    logger.info(`🚀 Fresh start — VANGUARD MD v${version.join('.')}`)
  }

  const sock = makeWASocket({
    version,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' })),
    },
    printQRInTerminal: false,
    logger: pino({ level: 'silent' }),
    browser: ['VANGUARD MD', 'Chrome', '1.0.0'],
    markOnlineOnConnect: config.alwaysOnline || defaults.alwaysOnline,
    getMessage: async () => ({ conversation: '' }),
  })

  // ── Pairing Code ───────────────────────────────────────────
  if (!state.creds.registered) {
    logger.warn('⚠️  No session found. Starting pairing...')
    await new Promise(r => setTimeout(r, 2000))

    let phone = await question(chalk.cyan('📱 Enter your WhatsApp number (with country code, no +): '))
    phone = phone.replace(/[^0-9]/g, '').trim()

    if (!phone || phone.length < 7) {
      logger.error('❌ Invalid phone number. Exiting.')
      process.exit(1)
    }

    try {
      const code = await sock.requestPairingCode(phone)
      logger.info(`\n🔑 Your Pairing Code: ${chalk.green.bold(code)}\n`)
      logger.info('👉 Go to WhatsApp > Linked Devices > Link with phone number > Enter code above')
    } catch (err) {
      logger.error(`❌ Failed to get pairing code: ${err.message}`)
      process.exit(1)
    }
  }

  // ── Save Credentials ───────────────────────────────────────
  sock.ev.on('creds.update', async () => {
    await saveCreds()

    // Extract and save owner number after first successful pair
    if (!config.ownerNumber && sock.authState?.creds?.me?.id) {
      const ownerJid = sock.authState.creds.me.id
      const ownerNumber = ownerJid.split(':')[0].split('@')[0]
      config.ownerNumber = ownerNumber  // Proxy auto-saves to data/config.json
      logger.info(`👑 Owner number saved: ${ownerNumber}`)
    }
  })

  // ── Connection Updates ─────────────────────────────────────
  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect } = update

    if (connection === 'connecting') {
      logger.info('🔄 Connecting to WhatsApp...')
    }

    if (connection === 'open') {
      rl.close()
      logger.success('✅ VANGUARD MD Connected Successfully!')
      logger.info(`👑 Owner  : ${config.ownerNumber || defaults.ownerNumber}`)
      logger.info(`🤖 Bot    : ${sock.user?.name || config.botName || 'VANGUARD MD'}`)
      logger.info(`📡 Mode   : ${config.mode || defaults.mode}`)
      logger.info(`🔑 Prefix : ${config.prefix || defaults.prefix}`)
      logger.info(`⚡ Commands: ${Object.keys(commands).length} loaded`)
      logger.info(`🔁 Session: ${isReturning ? 'Returning ✅' : 'Fresh install 🎉'}`)

      // ── Send startup message to owner ──────────────────────
      try {
        const ownerJid = (config.ownerNumber || defaults.ownerNumber) + '@s.whatsapp.net'
        await sock.sendMessage(ownerJid, { text: buildStartupMessage(isReturning) })
      } catch (_) {}

      // ── Start 24hr cleanup scheduler ───────────────────────
      startCleanupScheduler()

      // ── Hand off to main.js ────────────────────────────────
      const main = require('./main')
      main(sock, commands)
    }

    if (connection === 'close') {
      const reason = lastDisconnect?.error?.output?.statusCode
      logger.warn(`⚠️  Connection closed. Reason: ${reason}`)

      const shouldReconnect = reason !== DisconnectReason.loggedOut

      if (shouldReconnect) {
        logger.info('♻️  Reconnecting in 5 seconds...')
        setTimeout(startVanguard, 5000)
      } else {
        logger.error('🚫 Logged out. Delete session folder and restart.')
        process.exit(1)
      }
    }
  })

  // ── Anti-Call ──────────────────────────────────────────────
  sock.ev.on('call', async (calls) => {
    if (!(config.anticall ?? defaults.anticall)) return
    for (const call of calls) {
      if (call.status === 'offer') {
        await sock.rejectCall(call.id, call.from)
        logger.info(`📵 Rejected call from ${call.from}`)
        try {
          await sock.sendMessage(call.from, {
            text: `❌ *Sorry, I don't accept calls.*\n_Please send a message instead._`
          })
        } catch (_) {}
      }
    }
  })

  return sock
}

// ── Graceful Error Handling ───────────────────────────────────
process.on('uncaughtException', (err) => {
  logger.error(`💥 Uncaught Exception: ${err.message}`)
  console.error(err)
})

process.on('unhandledRejection', (reason) => {
  logger.error(`💥 Unhandled Rejection: ${reason}`)
})

// ── Launch ────────────────────────────────────────────────────
startVanguard()
