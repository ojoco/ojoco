// ============================================================
//  VANGUARD MD — defaults.js
//  Read-only default values — never modified at runtime
// ============================================================

module.exports = {
  // ── Bot Identity ───────────────────────────────────────────
  botName:      'VANGUARD MD',
  prefix:       '.',
  ownerNumber:  '',
  sudoNumbers:  [],

  // ── Mode ──────────────────────────────────────────────────
  mode: 'public',

  // ── Auto Features ─────────────────────────────────────────
  autoRead:         false,
  autoType:         false,
  autoRecord:       false,   // 🎙️ Recording flex on every message
  autoRecordType:   false,   // 🔀 Random typing + recording split (7s)
  alwaysOnline:     true,
  autoViewStatus:   false,
  autoReactStatus:  false,
  chatbot:          true,
  anticall:         true,

  // ── Status Reaction Emojis ─────────────────────────────────
  statusEmojis: ['💙', '💚'],

  // ── Privacy / Anti Features ───────────────────────────────
  antidelete:       true,
  antideleteStatus: true,
  antiedit:         true,

  // ── Group Defaults ─────────────────────────────────────────
  antilink:               false,
  antilinkAction:         'warn',
  antigroupmention:       false,
  antigroupmentionAction: 'warn',
  antisticker:            false,
  antistickerAction:      'warn',
  antimedia:              false,
  antimediaAction:        'warn',
  antibadword:            false,
  antibadwordAction:      'warn',

  // ── Economy ───────────────────────────────────────────────
  startingBalance:  1000,
  dailyReward:      500,
  workMinReward:    100,
  workMaxReward:    800,
  robSuccessChance: 0.45,

  // ── Cooldown ──────────────────────────────────────────────
  cooldownMs: 5000,

  // ── Repo Info ─────────────────────────────────────────────
  repoUrl:  'https://github.com/vanguard-md/bot',
  repoName: 'VANGUARD MD',
  repoDesc: 'A powerful WhatsApp bot built with Baileys',
}
