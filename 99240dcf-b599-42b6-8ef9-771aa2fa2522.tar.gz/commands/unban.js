// ============================================================
//  VANGUARD MD — commands/unban.js
// ============================================================

const fs = require('fs')
const path = require('path')
const { jidToNum } = require('../lib/utils')

const BAN_FILE = path.join(__dirname, '..', 'data', 'banned.json')

const getBanned = () => {
  try {
    if (!fs.existsSync(BAN_FILE)) return []
    return JSON.parse(fs.readFileSync(BAN_FILE, 'utf8'))
  } catch { return [] }
}

const saveBanned = (list) => {
  try {
    fs.writeFileSync(BAN_FILE, JSON.stringify(list, null, 2))
  } catch (_) {}
}

module.exports = async (ctx) => {
  const { reply, mentions, quoted, isOwner } = ctx
  if (!isOwner) return reply('❌ Only owner can use this command!')

  let target = mentions?.[0] || null
  if (!target && quoted?.sender) target = quoted.sender
  if (!target) return reply('❌ Mention or reply to someone to unban!\n_Example: .unban @user_')

  const targetNum = jidToNum(target)
  const banned = getBanned()

  if (!banned.includes(targetNum)) {
    return reply({
      text: `⚠️ @${targetNum} is not banned!`,
      mentions: [target],
    })
  }

  const updated = banned.filter(n => n !== targetNum)
  saveBanned(updated)

  await reply({
    text: `
━━━━━━━━━━━━━━━━━━━━━
✅ *USER UNBANNED*
━━━━━━━━━━━━━━━━━━━━━
👤 @${targetNum} has been unbanned.
✅ Bot will now respond to this user.
━━━━━━━━━━━━━━━━━━━━━
`.trim(),
    mentions: [target],
  })
}
