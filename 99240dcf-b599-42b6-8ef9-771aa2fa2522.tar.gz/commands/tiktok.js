// ============================================================
//  VANGUARD MD — commands/tiktok.js
//  TikTok video downloader — no watermark
// ============================================================

const axios = require('axios')

const TIKTOK_REGEX = /https?:\/\/(?:(?:www|vm|vt|m)\.)?tiktok\.com\/[^\s]+/i

const AXIOS_OPTS = {
  timeout: 15000,
  headers: {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': '*/*',
  },
}

// ── API chain ─────────────────────────────────────────────────
const apis = [
  async (url) => {
    const r = await axios.get(
      'https://api.siputzx.my.id/api/d/tiktok?url=' + encodeURIComponent(url),
      AXIOS_OPTS
    )
    if (!r.data?.status || !r.data?.data) throw new Error('no data')
    const d = r.data.data
    const videoUrl =
      (d.urls && d.urls[0])  ||
      d.video_url             ||
      d.url                   ||
      d.download_url          ||
      null
    if (!videoUrl) throw new Error('no video url')
    return { download: videoUrl, title: d.metadata?.title || 'TikTok Video' }
  },
  async (url) => {
    const r = await axios.get(
      'https://api.yupra.my.id/api/downloader/tiktok?url=' + encodeURIComponent(url),
      AXIOS_OPTS
    )
    if (r.data?.success && r.data?.data?.download_url) return {
      download: r.data.data.download_url,
      title:    r.data.data.title || 'TikTok Video',
    }
    throw new Error('no download')
  },
  async (url) => {
    const r = await axios.get(
      'https://okatsu-rolezapiiz.vercel.app/downloader/tiktok?url=' + encodeURIComponent(url),
      AXIOS_OPTS
    )
    if (r.data?.result?.video) return {
      download: r.data.result.video,
      title:    r.data.result.title || 'TikTok Video',
    }
    throw new Error('no download')
  },
]

const getVideoData = async (url) => {
  for (const api of apis) {
    try {
      const data = await api(url)
      if (data?.download) return data
    } catch (_) {}
  }
  throw new Error('All download sources failed')
}

module.exports = async (ctx) => {
  const { sock, msg, jid, args, reply } = ctx
  const config   = require('../config')
  const defaults = require('../defaults')

  const url = args.join(' ').trim()

  if (!url) return reply(
    '🎵 *TIKTOK DOWNLOADER*\n' +
    '━━━━━━━━━━━━━━━━━━━━━\n' +
    '_Usage: .tiktok <tiktok link>_'
  )

  if (!TIKTOK_REGEX.test(url)) return reply(
    '❌ That is not a valid TikTok link!\n' +
    '_Example: .tiktok https://vm.tiktok.com/xxx_'
  )

  await reply('⏳ *Downloading TikTok video...*')

  let videoData
  try {
    videoData = await getVideoData(url)
  } catch (err) {
    return reply('❌ Failed to download video. Please try again with a different link.')
  }

  const botName  = config.botName || defaults.botName || 'VANGUARD MD'
  const title    = videoData.title
  const caption  =
    '*' + title + '*\n\n' +
    '━━━━━━━━━━━━━━━━━━━━━\n' +
    '> _Powered by ' + botName + '_ 🔥'

  // ── Try buffer download first, fall back to URL stream ────
  try {
    const { data: videoBuffer } = await axios.get(videoData.download, {
      responseType: 'arraybuffer',
      timeout:      60000,
      maxContentLength: 100 * 1024 * 1024,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Referer':    'https://www.tiktok.com/',
      },
    })

    await sock.sendMessage(jid, {
      video:    Buffer.from(videoBuffer),
      mimetype: 'video/mp4',
      caption,
    }, { quoted: msg })

  } catch (_) {
    // ── Buffer failed — stream directly from URL ──────────
    try {
      await sock.sendMessage(jid, {
        video:    { url: videoData.download },
        mimetype: 'video/mp4',
        caption,
      }, { quoted: msg })
    } catch (err) {
      await reply('❌ Failed to send video: ' + err.message)
    }
  }
}
