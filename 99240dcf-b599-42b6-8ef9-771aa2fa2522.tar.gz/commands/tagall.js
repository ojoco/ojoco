// ============================================================
//  VANGUARD MD — commands/tagall.js
// ============================================================

module.exports = async (ctx) => {
  const { reply, sock, jid, fromGroup, args, isSudo } = ctx

  if (!fromGroup) return reply('❌ This command can only be used in groups!')
  if (!isSudo) return reply('❌ Only admins can use this command!')

  try {
    const meta = await sock.groupMetadata(jid)
    const all = meta.participants
    const mentions = all.map(p => p.id)
    const message = args.join(' ') || '👋 Attention everyone!'

    const tagList = all.map(p => `@${p.id.split('@')[0]}`).join('\n')

    await sock.sendMessage(jid, {
      text: `
━━━━━━━━━━━━━━━━━━━━━
📢 *TAG ALL*
━━━━━━━━━━━━━━━━━━━━━
💬 ${message}
━━━━━━━━━━━━━━━━━━━━━
${tagList}
━━━━━━━━━━━━━━━━━━━━━
`.trim(),
      mentions,
    })
  } catch (err) {
    await reply(`❌ Failed to tag all: ${err.message}`)
  }
}
