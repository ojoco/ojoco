// ============================================================
//  VANGUARD MD — commands/anticall.js
// ============================================================

const config = require('../config')

module.exports = async (ctx) => {
  const { reply, args, isSudo } = ctx
  if (!isSudo) return reply('❌ Only sudo/owner can use this command!')

  const state = args[0]?.toLowerCase()
  if (!state || !['on', 'off'].includes(state)) {
    return reply(`❌ Usage: *.anticall on/off*\n📍 Current: *${config.anticall ? 'ON' : 'OFF'}*`)
  }

  config.anticall = state === 'on'

  await reply(`
━━━━━━━━━━━━━━━━━━━━━
📵 *ANTI-CALL*
━━━━━━━━━━━━━━━━━━━━━
${config.anticall ? '✅ ON — Calls will be rejected automatically' : '❌ OFF — Calls will not be rejected'}
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}
