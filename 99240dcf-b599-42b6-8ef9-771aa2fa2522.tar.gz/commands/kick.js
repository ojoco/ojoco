// ============================================================
//  VANGUARD MD — commands/kick.js
// ============================================================

const { isBotAdmin, isSenderAdmin, jidToNum } = require('../lib/utils')

module.exports = async (ctx) => {
  const { reply, sock, jid, fromGroup, sender, mentions, quoted, isSudo } = ctx

  if (!fromGroup) return reply('❌ This command can only be used in groups!')
  if (!isSudo) return reply('❌ Only sudo/owner can use this command!')

  const botAdmin = await isBotAdmin(sock, jid)
  if (!botAdmin) return reply('❌ I need to be an admin to kick members!')

  let target = mentions?.[0] || null
  if (!target && quoted?.sender) target = quoted.sender
  if (!target) return reply('❌ Mention or reply to someone to kick!\n_Example: .kick @user_')

  if (target === sender) return reply('❌ You cannot kick yourself!')

  // Protect admins from being kicked
  const targetIsAdmin = await isSenderAdmin(sock, jid, target)
  if (targetIsAdmin) return reply('❌ Cannot kick an admin!')

  const targetNum = jidToNum(target)

  try {
    await sock.groupParticipantsUpdate(jid, [target], 'remove')
    await reply({
      text: `
━━━━━━━━━━━━━━━━━━━━━
👢 *KICKED*
━━━━━━━━━━━━━━━━━━━━━
🚫 @${targetNum} has been removed from the group.
━━━━━━━━━━━━━━━━━━━━━
`.trim(),
      mentions: [target],
    })
  } catch (err) {
    await reply(`❌ Failed to kick: ${err.message}`)
  }
}
