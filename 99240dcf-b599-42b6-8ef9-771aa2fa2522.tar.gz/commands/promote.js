// ============================================================
//  VANGUARD MD — commands/promote.js
// ============================================================

const { isBotAdmin, isSenderAdmin, jidToNum } = require('../lib/utils')

module.exports = async (ctx) => {
  const { reply, sock, jid, fromGroup, sender, mentions, quoted, isSudo } = ctx

  if (!fromGroup) return reply('❌ This command can only be used in groups!')
  if (!isSudo) return reply('❌ Only sudo/owner can use this command!')

  const botAdmin = await isBotAdmin(sock, jid)
  if (!botAdmin) return reply('❌ I need to be an admin to promote members!')

  let target = mentions?.[0] || null
  if (!target && quoted?.sender) target = quoted.sender
  if (!target) return reply('❌ Mention or reply to someone to promote!\n_Example: .promote @user_')

  if (target === sender) return reply('❌ You cannot promote yourself!')

  const targetNum = jidToNum(target)

  try {
    await sock.groupParticipantsUpdate(jid, [target], 'promote')
    await reply({
      text: `
━━━━━━━━━━━━━━━━━━━━━
⭐ *PROMOTED*
━━━━━━━━━━━━━━━━━━━━━
🎉 @${targetNum} is now an admin!
━━━━━━━━━━━━━━━━━━━━━
`.trim(),
      mentions: [target],
    })
  } catch (err) {
    await reply(`❌ Failed to promote: ${err.message}`)
  }
}
