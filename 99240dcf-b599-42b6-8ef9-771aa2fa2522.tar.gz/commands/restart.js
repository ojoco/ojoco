// ============================================================
//  VANGUARD MD — commands/restart.js
// ============================================================

module.exports = async (ctx) => {
  const { reply, isOwner } = ctx
  if (!isOwner) return reply('❌ Only owner can use this command!')

  await reply(`
━━━━━━━━━━━━━━━━━━━━━
♻️ *RESTARTING BOT*
━━━━━━━━━━━━━━━━━━━━━
🔄 VANGUARD MD is restarting...
⏳ Please wait a few seconds.
━━━━━━━━━━━━━━━━━━━━━
`)

  setTimeout(() => {
    process.exit(0)
  }, 2000)
}
