// ============================================================
//  VANGUARD MD — commands/block.js
// ============================================================

const { jidToNum, numToJid } = require('../lib/utils')

module.exports = async (ctx) => {
  const { reply, sock, mentions, quoted, isOwner } = ctx
  if (!isOwner) return reply('❌ Only owner can use this command!')

  let target = mentions?.[0] || null
  if (!target && quoted?.sender) target = quoted.sender
  if (!target) return reply('❌ Mention or reply to someone to block!\n_Example: .block @user_')

  const targetNum = jidToNum(target)

  try {
    await sock.updateBlockStatus(target, 'block')
    await reply({
      text: `
━━━━━━━━━━━━━━━━━━━━━
🚫 *USER BLOCKED*
━━━━━━━━━━━━━━━━━━━━━
👤 @${targetNum} has been blocked.
━━━━━━━━━━━━━━━━━━━━━
`.trim(),
      mentions: [target],
    })
  } catch (err) {
    await reply(`❌ Failed to block: ${err.message}`)
  }
}
