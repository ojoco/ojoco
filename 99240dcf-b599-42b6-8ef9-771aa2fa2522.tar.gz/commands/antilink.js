// ============================================================
//  VANGUARD MD — commands/antilink.js
// ============================================================

const { isBotAdmin, isSenderAdmin, saveGroupSettings, getGroupSettings, addWarn, resetWarns, jidToNum } = require('../lib/utils')

// ── Link detection — layered approach ────────────────────────
// Layer 1: explicit protocol links (http/https/ftp)
const PROTOCOL_REGEX = /https?:\/\/[^\s]+|ftp:\/\/[^\s]+/i

// Layer 2: www. links
const WWW_REGEX = /www\.[a-z0-9-]+\.[a-z]{2,}[^\s]*/i

// Layer 3: WhatsApp invite links
const WA_REGEX = /chat\.whatsapp\.com\/[^\s]+/i

// Layer 4: known shorteners + popular domains (bare, no www/https)
const SHORTENER_REGEX = /\b(?:bit\.ly|t\.me|tinyurl\.com|goo\.gl|ow\.ly|buff\.ly|rb\.gy|is\.gd|short\.io|tiny\.cc|cutt\.ly|youtu\.be|vm\.tiktok\.com|instagram\.com|facebook\.com|fb\.com|twitter\.com|x\.com|telegram\.me|discord\.gg|discord\.com\/invite|linktr\.ee|wa\.me)\/[^\s]*/i

// Layer 5: general bare domain — TLD list to avoid false positives like "e.g" or "Mr.Admin"
// Only fires if followed by / or common TLD patterns with path
const BARE_DOMAIN_REGEX = /\b[a-z0-9-]{2,}\.(com|net|org|io|co|app|dev|xyz|info|biz|gg|tv|me|ly|link|site|web|online|store|shop|live|news|media|tech|ai|cloud)(?:\/[^\s]*)?\b/i

const containsLink = (text) => {
  if (!text || typeof text !== 'string') return false
  return (
    PROTOCOL_REGEX.test(text) ||
    WWW_REGEX.test(text)      ||
    WA_REGEX.test(text)       ||
    SHORTENER_REGEX.test(text)||
    BARE_DOMAIN_REGEX.test(text)
  )
}

module.exports = async (ctx) => {
  const { reply, jid, fromGroup, args, isSudo } = ctx

  if (!fromGroup) return reply('❌ This command can only be used in groups!')
  if (!isSudo) return reply('❌ Only sudo/owner can use this command!')

  const action = args[0]?.toLowerCase()
  const state  = args[1]?.toLowerCase()

  const validActions = ['warn', 'delete', 'remove']
  const validStates  = ['on', 'off']

  if (!action || !validActions.includes(action) || !state || !validStates.includes(state)) {
    const settings = getGroupSettings(jid)
    return reply(`
❌ Usage: *.antilink <action> on/off*
━━━━━━━━━━━━━━━━━━━━━
Actions:
• warn — Delete + add strike (3 = kick)
• delete — Just delete the link
• remove — Delete + remove sender
━━━━━━━━━━━━━━━━━━━━━
📍 Current: *${settings.antilink ? 'ON' : 'OFF'}*
⚙️ Action: *${settings.antilinkAction || 'warn'}*
━━━━━━━━━━━━━━━━━━━━━
_Example: .antilink warn on_
`.trim())
  }

  saveGroupSettings(jid, {
    antilink:       state === 'on',
    antilinkAction: action,
  })

  await reply(`
━━━━━━━━━━━━━━━━━━━━━
🔗 *ANTI LINK*
━━━━━━━━━━━━━━━━━━━━━
${state === 'on'
  ? `✅ ON — Action: *${action.toUpperCase()}*\n_Links sent by non-admins will be ${
      action === 'warn'   ? 'deleted and warned (3 = kick)' :
      action === 'delete' ? 'deleted silently' :
                            'deleted and user removed'}_`
  : '❌ OFF — Links are now allowed'}
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}

// ── Enforcer — called from main.js on every group message ─────
module.exports.enforce = async (sock, msg, jid, sender) => {
  try {
    const settings = getGroupSettings(jid)
    if (!settings.antilink) return

    // ── Extract text from all message types ───────────────
    const body = (
      msg.message?.conversation ||
      msg.message?.extendedTextMessage?.text ||
      msg.message?.imageMessage?.caption ||
      msg.message?.videoMessage?.caption ||
      msg.message?.documentMessage?.caption ||
      msg.message?.buttonsResponseMessage?.selectedButtonId ||
      ''
    )

    if (!containsLink(body)) return

    const botAdmin = await isBotAdmin(sock, jid)
    if (!botAdmin) return

    const senderAdmin = await isSenderAdmin(sock, jid, sender)
    if (senderAdmin) return

    const action    = settings.antilinkAction || 'warn'
    const senderNum = jidToNum(sender)

    // ── Always delete the offending message first ─────────
    try { await sock.sendMessage(jid, { delete: msg.key }) } catch (_) {}

    // ── warn: strike + auto-kick at 3 ─────────────────────
    if (action === 'warn') {
      const newCount = addWarn(jid, senderNum, 'antilink')

      if (newCount >= 3) {
        resetWarns(jid, senderNum)
        try {
          await sock.groupParticipantsUpdate(jid, [sender], 'remove')
          await sock.sendMessage(jid, {
            text:     `🚨 @${senderNum} has been removed after *3 warnings* for sending links.`,
            mentions: [sender],
          })
        } catch (_) {
          await sock.sendMessage(jid, {
            text:     `🚨 @${senderNum} reached *3 warnings* for sending links. Could not remove — please do so manually.`,
            mentions: [sender],
          })
        }
      } else {
        await sock.sendMessage(jid, {
          text:
            `⚠️ *Warning ${newCount}/3* — @${senderNum}\n` +
            `🔗 Links are not allowed in this group!\n` +
            `${newCount === 2 ? '_⚠️ One more violation = removal_' : ''}`,
          mentions: [sender],
        })
      }

    // ── delete: silent delete + notification ──────────────
    } else if (action === 'delete') {
      await sock.sendMessage(jid, {
        text:     `🔗 @${senderNum} links are not allowed in this group!`,
        mentions: [sender],
      })

    // ── remove: instant kick ──────────────────────────────
    } else if (action === 'remove') {
      try {
        await sock.groupParticipantsUpdate(jid, [sender], 'remove')
        await sock.sendMessage(jid, {
          text:     `🚫 @${senderNum} was removed for sending a link.`,
          mentions: [sender],
        })
      } catch (_) {}
    }

  } catch (err) {
    require('../lib/logger').error(`🔗 Antilink enforce error: ${err.message}`)
  }
}
