// ============================================================
//  VANGUARD MD — commands/repo.js
// ============================================================

const config = require('../config')
const defaults = require('../defaults')

module.exports = async (ctx) => {
  const { reply } = ctx
  await reply(`
━━━━━━━━━━━━━━━━━━━━━
📦 *REPOSITORY INFO*
━━━━━━━━━━━━━━━━━━━━━
🤖 Bot: *${config.botName || defaults.botName}*
📁 Repo: *${config.repoName || defaults.repoName}*
🔗 URL: ${config.repoUrl || defaults.repoUrl}
📝 About: _${config.repoDesc || defaults.repoDesc}_
━━━━━━━━━━━━━━━━━━━━━
⭐ Star the repo if you enjoy the bot!
🍴 Fork it to build your own version.
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}
