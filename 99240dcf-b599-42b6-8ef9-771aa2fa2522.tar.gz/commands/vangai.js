// ============================================================
//  VANGUARD MD — commands/vangai.js
//  AI assistant — Gemini chain + GPT fallback
// ============================================================

const axios = require('axios')

// ── Gemini API chain (primary) ────────────────────────────────
const geminiApis = [
  async (q) => {
    const r = await axios.get(`https://vapis.my.id/api/gemini?q=${encodeURIComponent(q)}`, { timeout: 15000 })
    const answer = r.data?.message || r.data?.data || r.data?.answer || r.data?.result
    if (answer) return answer
    throw new Error('no answer')
  },
  async (q) => {
    const r = await axios.get(`https://api.siputzx.my.id/api/ai/gemini-pro?content=${encodeURIComponent(q)}`, { timeout: 15000 })
    const answer = r.data?.message || r.data?.data || r.data?.answer || r.data?.result
    if (answer) return answer
    throw new Error('no answer')
  },
  async (q) => {
    const r = await axios.get(`https://api.ryzendesu.vip/api/ai/gemini?text=${encodeURIComponent(q)}`, { timeout: 15000 })
    const answer = r.data?.message || r.data?.data || r.data?.answer || r.data?.result
    if (answer) return answer
    throw new Error('no answer')
  },
  async (q) => {
    const r = await axios.get(`https://zellapi.autos/ai/chatbot?text=${encodeURIComponent(q)}`, { timeout: 15000 })
    const answer = r.data?.message || r.data?.data || r.data?.answer || r.data?.result
    if (answer) return answer
    throw new Error('no answer')
  },
  async (q) => {
    const r = await axios.get(`https://api.giftedtech.my.id/api/ai/geminiai?apikey=gifted&q=${encodeURIComponent(q)}`, { timeout: 15000 })
    const answer = r.data?.message || r.data?.data || r.data?.answer || r.data?.result
    if (answer) return answer
    throw new Error('no answer')
  },
  async (q) => {
    const r = await axios.get(`https://api.giftedtech.my.id/api/ai/geminiaipro?apikey=gifted&q=${encodeURIComponent(q)}`, { timeout: 15000 })
    const answer = r.data?.message || r.data?.data || r.data?.answer || r.data?.result
    if (answer) return answer
    throw new Error('no answer')
  },
]

// ── GPT fallback (final) ──────────────────────────────────────
const gptFallback = async (q) => {
  const r = await axios.get(`https://zellapi.autos/ai/chatbot?text=${encodeURIComponent(q)}`, { timeout: 15000 })
  const answer = r.data?.result || r.data?.message || r.data?.data || r.data?.answer
  if (answer) return answer
  throw new Error('GPT fallback failed')
}

const getAiAnswer = async (query) => {
  for (const api of geminiApis) {
    try {
      const answer = await api(query)
      if (answer) return answer
    } catch (_) {}
  }
  return await gptFallback(query)
}

module.exports = async (ctx) => {
  const { sock, msg, jid, args, reply } = ctx

  const query = args.join(' ').trim()
  if (!query) return reply(
    `🤖 *VANGAI — AI Assistant*\n` +
    `━━━━━━━━━━━━━━━━━━━━━\n` +
    `_Usage: .vangai <your question>_\n\n` +
    `_Example: .vangai explain quantum physics_`
  )

  // ── Thinking indicator ────────────────────────────────────
  await reply('*_Thinking 🧠_*')

  // ── Get answer ────────────────────────────────────────────
  let answer
  try {
    answer = await getAiAnswer(query)
  } catch (err) {
    return reply(`❌ All AI sources failed. Please try again later.`)
  }

  // ── Send response ─────────────────────────────────────────
  await reply(
    `🤖 *VANGAI*\n` +
    `━━━━━━━━━━━━━━━━━━━━━\n` +
    `❓ *Query:* ${query}\n` +
    `━━━━━━━━━━━━━━━━━━━━━\n\n` +
    `${answer}\n\n` +
    `━━━━━━━━━━━━━━━━━━━━━\n` +
    `> _Powered by VANGUARD MD_ 🔥`
  )
}
