// ============================================================
//  VANGUARD MD — commands/runtime.js
// ============================================================

const { formatUptime } = require('../lib/utils')

module.exports = async (ctx) => {
  const { reply } = ctx
  const uptime = formatUptime(process.uptime())
  await reply(`⏱️ *Bot Runtime*\n\n🟢 VANGUARD MD has been running for:\n*${uptime}*`)
}
