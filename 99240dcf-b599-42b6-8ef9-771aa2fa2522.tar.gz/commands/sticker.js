// ============================================================
//  VANGUARD MD — commands/sticker.js
// ============================================================

const fs = require('fs')
const path = require('path')
const ffmpeg = require('fluent-ffmpeg')
const ffmpegStatic = require('ffmpeg-static')
const { tmpdir } = require('os')
const { promisify } = require('util')
const { downloadMediaMessage } = require('@whiskeysockets/baileys')
const config = require('../config')
const defaults = require('../defaults')

ffmpeg.setFfmpegPath(ffmpegStatic)

const convertToSticker = (inputPath, outputPath, isVideo = false) => {
  return new Promise((resolve, reject) => {
    let cmd = ffmpeg(inputPath)
      .outputOptions([
        '-vcodec', 'libwebp',
        '-vf', isVideo
          ? 'scale=512:512:force_original_aspect_ratio=decrease,fps=15,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=white@0.0,split[a][b];[a]palettegen=reserve_transparent=on:transparency_color=ffffff[p];[b][p]paletteuse'
          : 'scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=white@0.0',
        '-loop', '0',
        '-ss', '00:00:00',
        '-t', '00:00:10',
        '-preset', 'default',
        '-an',
        '-vsync', '0',
        '-s', '512:512',
      ])
      .toFormat('webp')
      .save(outputPath)
      .on('end', resolve)
      .on('error', reject)
  })
}

module.exports = async (ctx) => {
  const { sock, msg, jid, quoted, reply } = ctx

  const target = quoted || msg
  const msgType = Object.keys(target.message || {})[0]
  const isImage = msgType === 'imageMessage'
  const isVideo = msgType === 'videoMessage'
  const isSticker = msgType === 'stickerMessage'

  if (!isImage && !isVideo) {
    return reply('❌ Please reply to or send an *image* or *video* to convert to sticker!\n_Usage: .sticker (reply to image/video)_')
  }

  await reply('⏳ *Creating sticker...*')

  try {
    const buffer = await downloadMediaMessage(
      { message: target.message, key: target.key },
      'buffer',
      {},
      { logger: require('pino')({ level: 'silent' }), reuploadRequest: sock.updateMediaMessage }
    )

    const ext = isVideo ? 'mp4' : 'jpg'
    const inputPath = path.join(tmpdir(), `vanguard_input_${Date.now()}.${ext}`)
    const outputPath = path.join(tmpdir(), `vanguard_sticker_${Date.now()}.webp`)

    fs.writeFileSync(inputPath, buffer)
    await convertToSticker(inputPath, outputPath, isVideo)

    const stickerBuffer = fs.readFileSync(outputPath)
    const botName = config.botName || defaults.botName

    await sock.sendMessage(jid, {
      sticker: stickerBuffer,
      mimetype: 'image/webp',
      stickerMetadata: {
        packname: botName,
        author: 'VANGUARD MD',
      }
    }, { quoted: msg })

    // Cleanup
    fs.unlinkSync(inputPath)
    fs.unlinkSync(outputPath)

  } catch (err) {
    await reply(`❌ Failed to create sticker: ${err.message}`)
  }
}
