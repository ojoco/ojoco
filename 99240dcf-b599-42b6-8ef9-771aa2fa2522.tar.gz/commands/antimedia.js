// ============================================================
//  VANGUARD MD — commands/antimedia.js
// ============================================================

const { saveGroupSettings, getGroupSettings, isBotAdmin, isSenderAdmin, addWarn, resetWarns, jidToNum } = require('../lib/utils')

const MEDIA_TYPES = ['imageMessage', 'videoMessage', 'audioMessage', 'documentMessage']

module.exports = async (ctx) => {
  const { reply, jid, fromGroup, args, isSudo } = ctx

  if (!fromGroup) return reply('❌ This command can only be used in groups!')
  if (!isSudo) return reply('❌ Only sudo/owner can use this command!')

  const action = args[0]?.toLowerCase()
  const state  = args[1]?.toLowerCase()

  const validActions = ['warn', 'delete', 'remove']
  const validStates  = ['on', 'off']

  if (!action || !validActions.includes(action) || !state || !validStates.includes(state)) {
    const settings = getGroupSettings(jid)
    return reply(`
❌ Usage: *.antimedia <action> on/off*
━━━━━━━━━━━━━━━━━━━━━
Actions:
• warn — Delete + add strike (3 = kick)
• delete — Just delete the media
• remove — Delete + remove sender
━━━━━━━━━━━━━━━━━━━━━
📍 Current: *${settings.antimedia ? 'ON' : 'OFF'}*
⚙️ Action: *${settings.antimediaAction || 'warn'}*
━━━━━━━━━━━━━━━━━━━━━
ℹ️ View-once messages are exempt
_Example: .antimedia delete on_
`.trim())
  }

  saveGroupSettings(jid, {
    antimedia:       state === 'on',
    antimediaAction: action,
  })

  await reply(`
━━━━━━━━━━━━━━━━━━━━━
🖼️ *ANTI MEDIA*
━━━━━━━━━━━━━━━━━━━━━
${state === 'on'
  ? `✅ ON — Action: *${action.toUpperCase()}*\n_Media from non-admins will be ${
      action === 'warn'   ? 'deleted and warned (3 = kick)' :
      action === 'delete' ? 'deleted silently' :
                            'deleted and user removed'}_\n_View-once is exempt_`
  : '❌ OFF — Media is now allowed'}
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}

// ── Enforcer — called from main.js on every group message ─────
module.exports.enforce = async (sock, msg, jid, sender) => {
  try {
    const settings = getGroupSettings(jid)
    if (!settings.antimedia) return

    const msgType = Object.keys(msg.message || {})[0]

    // ── Exempt view-once entirely ─────────────────────────
    if (
      msgType === 'viewOnceMessage' ||
      msgType === 'viewOnceMessageV2' ||
      msgType === 'viewOnceMessageV2Extension'
    ) return

    if (!MEDIA_TYPES.includes(msgType)) return

    const botAdmin = await isBotAdmin(sock, jid)
    if (!botAdmin) return

    const senderAdmin = await isSenderAdmin(sock, jid, sender)
    if (senderAdmin) return

    const action    = settings.antimediaAction || 'warn'
    const senderNum = jidToNum(sender)

    // ── Always delete the media first ─────────────────────
    try { await sock.sendMessage(jid, { delete: msg.key }) } catch (_) {}

    // ── warn: strike + auto-kick at 3 ─────────────────────
    if (action === 'warn') {
      const newCount = addWarn(jid, senderNum, 'antimedia')

      if (newCount >= 3) {
        resetWarns(jid, senderNum)
        try {
          await sock.groupParticipantsUpdate(jid, [sender], 'remove')
          await sock.sendMessage(jid, {
            text:     `🚨 @${senderNum} has been removed after *3 warnings* for sending media.`,
            mentions: [sender],
          })
        } catch (_) {
          await sock.sendMessage(jid, {
            text:     `🚨 @${senderNum} reached *3 warnings* for sending media. Could not remove — please do so manually.`,
            mentions: [sender],
          })
        }
      } else {
        await sock.sendMessage(jid, {
          text:
            `⚠️ *Warning ${newCount}/3* — @${senderNum}\n` +
            `🖼️ Media is not allowed in this group!\n` +
            `${newCount === 2 ? '_⚠️ One more violation = removal_' : ''}`,
          mentions: [sender],
        })
      }

    // ── delete: silent delete + notification ──────────────
    } else if (action === 'delete') {
      await sock.sendMessage(jid, {
        text:     `🖼️ @${senderNum} media is not allowed in this group!`,
        mentions: [sender],
      })

    // ── remove: instant kick ──────────────────────────────
    } else if (action === 'remove') {
      try {
        await sock.groupParticipantsUpdate(jid, [sender], 'remove')
        await sock.sendMessage(jid, {
          text:     `🚫 @${senderNum} was removed for sending media.`,
          mentions: [sender],
        })
      } catch (_) {}
    }

  } catch (err) {
    require('../lib/logger').error(`🖼️ Antimedia enforce error: ${err.message}`)
  }
}
