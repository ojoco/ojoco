// ============================================================
//  VANGUARD MD — commands/rob.js
// ============================================================

const { getBalance, getEconomy, saveEconomy, jidToNum, randInt } = require('../lib/utils')
const config = require('../config')
const defaults = require('../defaults')

const robCooldowns = new Map()
const ROB_COOLDOWN = 30 * 60 * 1000 // 30 minutes

module.exports = async (ctx) => {
  const { reply, sender, mentions, quoted } = ctx
  const senderNum = jidToNum(sender)

  // Get target
  let target = mentions?.[0] || null
  if (!target && quoted?.sender) target = quoted.sender
  if (!target) {
    return reply('❌ Mention or reply to someone to rob!\n_Example: .rob @user_')
  }

  if (target === sender) {
    return reply('❌ You cannot rob yourself!')
  }

  const targetNum = jidToNum(target)

  // Cooldown check
  const coolKey = `${senderNum}:rob`
  const lastRob = robCooldowns.get(coolKey) || 0
  const now = Date.now()

  if (now - lastRob < ROB_COOLDOWN) {
    const remaining = ROB_COOLDOWN - (now - lastRob)
    const mins = Math.floor(remaining / 60000)
    const secs = Math.floor((remaining % 60000) / 1000)
    return reply(`⏳ *Lay Low!*\n\nPolice are watching! Try again in *${mins}m ${secs}s*`)
  }

  const robberAccount = getBalance(senderNum)
  const victimAccount = getBalance(targetNum)

  if (victimAccount.balance < 100) {
    return reply({
      text: `💸 @${targetNum} is *broke!* Nothing to steal here 😂`,
      mentions: [target],
    })
  }

  const successChance = config.robSuccessChance || defaults.robSuccessChance
  const success = Math.random() < successChance

  const data = getEconomy()
  robCooldowns.set(coolKey, now)

  if (success) {
    // Steal between 10-40% of victim's balance
    const percent = randInt(10, 40) / 100
    const stolen = Math.floor(victimAccount.balance * percent)

    data[senderNum] = data[senderNum] || {}
    data[targetNum] = data[targetNum] || {}
    data[senderNum].balance = robberAccount.balance + stolen
    data[targetNum].balance = victimAccount.balance - stolen
    saveEconomy(data)

    await reply({
      text: `
━━━━━━━━━━━━━━━━━━━━━
🦹 *ROBBERY SUCCESS!*
━━━━━━━━━━━━━━━━━━━━━
😈 @${senderNum} robbed @${targetNum}!
━━━━━━━━━━━━━━━━━━━━━
💰 Stolen: *$${stolen.toLocaleString()}*
💵 Your Balance: *$${(robberAccount.balance + stolen).toLocaleString()}*
😢 Victim Left: *$${(victimAccount.balance - stolen).toLocaleString()}*
━━━━━━━━━━━━━━━━━━━━━
🚨 Make a run for it!
━━━━━━━━━━━━━━━━━━━━━
`.trim(),
      mentions: [sender, target],
    })

  } else {
    // Failed — lose 10-20% of robber's balance as fine
    const fine = Math.floor(robberAccount.balance * (randInt(10, 20) / 100))
    data[senderNum] = data[senderNum] || {}
    data[senderNum].balance = Math.max(0, robberAccount.balance - fine)
    saveEconomy(data)

    await reply({
      text: `
━━━━━━━━━━━━━━━━━━━━━
🚨 *ROBBERY FAILED!*
━━━━━━━━━━━━━━━━━━━━━
👮 @${senderNum} got caught trying to rob @${targetNum}!
━━━━━━━━━━━━━━━━━━━━━
💸 Fine Paid: *-$${fine.toLocaleString()}*
💵 Your Balance: *$${Math.max(0, robberAccount.balance - fine).toLocaleString()}*
━━━━━━━━━━━━━━━━━━━━━
😂 Better luck next time!
━━━━━━━━━━━━━━━━━━━━━
`.trim(),
      mentions: [sender, target],
    })
  }
}
