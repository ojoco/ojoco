// ============================================================
//  VANGUARD MD — commands/antidelete.js
// ============================================================

const config = require('../config')

module.exports = async (ctx) => {
  const { reply, args, isSudo } = ctx
  if (!isSudo) return reply('❌ Only sudo/owner can use this command!')

  const state = args[0]?.toLowerCase()
  if (!state || !['on', 'off'].includes(state)) {
    return reply(`❌ Usage: *.antidelete on/off*\n📍 Current: *${config.antidelete ? 'ON' : 'OFF'}*`)
  }

  config.antidelete = state === 'on'

  await reply(`
━━━━━━━━━━━━━━━━━━━━━
🗑️ *ANTI DELETE*
━━━━━━━━━━━━━━━━━━━━━
${config.antidelete
  ? '✅ ON — Deleted messages will be forwarded to owner inbox'
  : '❌ OFF — Deleted messages will be ignored'}
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}
