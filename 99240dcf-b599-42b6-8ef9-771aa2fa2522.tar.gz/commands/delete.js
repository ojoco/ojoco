// ============================================================
//  VANGUARD MD — commands/delete.js
//  Handles all delete modes:
//  • .delete          → delete quoted message (own or group with admin)
//  • .delete 20       → bulk delete last N messages in chat
//  • .delete 20 @user → bulk delete last N messages by specific user
// ============================================================

const { isBotAdmin } = require('../lib/utils')
const { getStoredMessages } = require('../lib/messageStore')

const MAX_BULK = 100

module.exports = async (ctx) => {
  const { sock, msg, jid, reply, quoted, args, fromGroup, fromMe, isSudo, senderNum, mentions } = ctx

  if (!isSudo) return reply('❌ Only sudo/owner can use this command!')

  const firstArg = args[0]
  const bulkCount = firstArg && /^\d+$/.test(firstArg) ? parseInt(firstArg) : null

  // ── Helper: delete a single message ──────────────────────
  const deleteMsg = async (msgKey) => {
    try {
      await sock.sendMessage(jid, { delete: msgKey })
      return true
    } catch (_) { return false }
  }

  // ── Helper: delete the command message itself ─────────────
  const deleteCommand = async () => {
    try {
      await sock.sendMessage(jid, {
        delete: { remoteJid: jid, id: msg.key.id, fromMe: true }
      })
    } catch (_) {}
  }

  // ════════════════════════════════════════════════════════
  //  MODE 1 — Quoted delete
  // ════════════════════════════════════════════════════════
  if (quoted && !bulkCount) {
    const isOwnMsg = quoted.sender
      ? quoted.sender.replace(/:[0-9]+@/, '@').replace('@s.whatsapp.net', '') === senderNum
      : false

    // ── Own message — always allowed ─────────────────────
    if (isOwnMsg || fromMe) {
      const ok = await deleteMsg({
        remoteJid:   jid,
        id:          quoted.stanzaId,
        fromMe:      true,
        participant: quoted.sender,
      })
      if (ok) {
        await deleteCommand()
      } else {
        // Try as not fromMe (edge case)
        await deleteMsg({
          remoteJid:   jid,
          id:          quoted.stanzaId,
          fromMe:      false,
          participant: quoted.sender,
        })
        await deleteCommand()
      }
      return
    }

    // ── Other's message in group — need bot admin ─────────
    if (fromGroup) {
      const botAdmin = await isBotAdmin(sock, jid)
      if (!botAdmin) return reply('❌ I need to be an admin to delete others\' messages!')

      // Check message exists in store
      const stored = getStoredMessages(jid)
      const exists = stored?.find(m => m.id === quoted.stanzaId)
      if (!exists) return reply(
        `⚠️ *Message not in my memory*\n` +
        `_This message is too old or was sent before I was deployed._`
      )

      const ok = await deleteMsg({
        remoteJid:   jid,
        id:          quoted.stanzaId,
        fromMe:      false,
        participant: quoted.sender,
      })
      if (ok) {
        await deleteCommand()
      } else {
        await reply('❌ Failed to delete — message may be too old for WhatsApp.')
      }
      return
    }

    // ── DM quoted — just try delete ───────────────────────
    await deleteMsg({
      remoteJid: jid,
      id:        quoted.stanzaId,
      fromMe:    false,
    })
    await deleteCommand()
    return
  }

  // ════════════════════════════════════════════════════════
  //  MODE 2 — Bulk delete
  // ════════════════════════════════════════════════════════
  if (bulkCount) {
    if (bulkCount > MAX_BULK) return reply(`❌ Maximum bulk delete is *${MAX_BULK}* messages.`)
    if (bulkCount < 1)        return reply(`❌ Please provide a valid number.`)

    // ── Need bot admin for bulk in groups ─────────────────
    if (fromGroup) {
      const botAdmin = await isBotAdmin(sock, jid)
      if (!botAdmin) return reply('❌ I need to be an admin to bulk delete messages!')
    }

    // ── Resolve target user if mentioned or quoted ────────
    let targetNum = null
    if (mentions?.length) {
      targetNum = mentions[0].replace(/:[0-9]+@/, '@').replace('@s.whatsapp.net', '')
    } else if (quoted?.sender) {
      targetNum = quoted.sender.replace(/:[0-9]+@/, '@').replace('@s.whatsapp.net', '')
    }

    // ── Pull from message store ───────────────────────────
    const stored = getStoredMessages(jid) || []
    if (stored.length === 0) return reply(
      `⚠️ *No messages in my memory for this chat.*\n` +
      `_Messages sent before deployment can't be recovered._`
    )

    // Filter by target if specified, then take last N
    const pool = targetNum
      ? stored.filter(m => {
          const mNum = (m.sender || '').replace(/:[0-9]+@/, '@').replace('@s.whatsapp.net', '')
          return mNum === targetNum
        })
      : stored

    if (pool.length === 0) return reply(
      `⚠️ *No messages found for that user in my memory.*`
    )

    // Take last N from pool (most recent)
    const toDelete = pool.slice(-bulkCount)
    const requested = toDelete.length
    const actualCount = Math.min(bulkCount, requested)

    if (actualCount === 0) return reply(
      `⚠️ *Nothing to delete.*\n_I only have ${pool.length} message(s) stored for this chat._`
    )

    // ── Delete them all ───────────────────────────────────
    let deleted = 0
    let failed  = 0

    for (const stored of toDelete) {
      try {
        await sock.sendMessage(jid, {
          delete: {
            remoteJid:   jid,
            id:          stored.id,
            fromMe:      stored.fromMe ?? false,
            participant: stored.sender,
          }
        })
        deleted++
      } catch (_) {
        failed++
      }
      // Small delay to avoid WA rate limiting
      await new Promise(r => setTimeout(r, 100))
    }

    // ── Delete the command message ────────────────────────
    await deleteCommand()

    // ── Summary ───────────────────────────────────────────
    const targetLine = targetNum ? `\n👤 Target: @${targetNum}` : ''
    const failLine   = failed > 0 ? `\n⚠️ Failed: *${failed}* (too old for WhatsApp)` : ''

    await sock.sendMessage(jid, {
      text:
        `🗑️ *Bulk Delete Complete*\n` +
        `━━━━━━━━━━━━━━━━━━━━━\n` +
        `✅ Deleted: *${deleted}/${requested}*` +
        targetLine +
        failLine + '\n' +
        `━━━━━━━━━━━━━━━━━━━━━`,
      mentions: targetNum ? [targetNum + '@s.whatsapp.net'] : [],
    })
    return
  }

  // ════════════════════════════════════════════════════════
  //  No args, no quoted — show usage
  // ════════════════════════════════════════════════════════
  await reply(
    `❌ *How to use delete:*\n` +
    `━━━━━━━━━━━━━━━━━━━━━\n` +
    `📌 Reply to a message → *${ctx.prefix}delete*\n` +
    `🗑️ Bulk delete last N → *${ctx.prefix}delete 20*\n` +
    `👤 Bulk by user → *${ctx.prefix}delete 20 @user*\n` +
    `━━━━━━━━━━━━━━━━━━━━━\n` +
    `_Max bulk: ${MAX_BULK} messages_`
  )
}
