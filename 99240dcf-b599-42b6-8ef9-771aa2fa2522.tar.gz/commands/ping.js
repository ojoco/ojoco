// ============================================================
//  VANGUARD MD — commands/ping.js
// ============================================================

module.exports = async (ctx) => {
  const { reply, msg, sock, jid } = ctx
  const start = Date.now()
  await sock.sendMessage(jid, { text: '🏓 Pinging...' }, { quoted: msg })
  const end = Date.now()
  const ms = end - start
  await reply(`🏓 *Pong!*\n⚡ Speed: *${ms}ms*`)
}
