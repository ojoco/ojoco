// ============================================================
//  VANGUARD MD — commands/autotype.js
// ============================================================

const config = require('../config')

module.exports = async (ctx) => {
  const { reply, args, isSudo, prefix } = ctx
  if (!isSudo) return reply('❌ Only sudo/owner can use this command!')

  const state = args[0]?.toLowerCase()
  if (!state || !['on', 'off'].includes(state)) {
    return reply(`❌ Usage: *.autotype on/off*\n📍 Current: *${config.autoType ? 'ON' : 'OFF'}*`)
  }

  // ── Mutual exclusion checks ───────────────────────────────
  if (state === 'on') {
    if (config.autoRecord) {
      return reply(
        `━━━━━━━━━━━━━━━━━━━━━\n` +
        `⚠️ *CONFLICT DETECTED*\n` +
        `━━━━━━━━━━━━━━━━━━━━━\n` +
        `🎙️ *AutoRecord* is currently ON\n` +
        `Toggle it off first:\n` +
        `*${prefix}autorecord off*\n` +
        `━━━━━━━━━━━━━━━━━━━━━`
      )
    }
    if (config.autoRecordType) {
      return reply(
        `━━━━━━━━━━━━━━━━━━━━━\n` +
        `⚠️ *CONFLICT DETECTED*\n` +
        `━━━━━━━━━━━━━━━━━━━━━\n` +
        `🔀 *AutoRecordType* is currently ON\n` +
        `Toggle it off first:\n` +
        `*${prefix}autorecordtype off*\n` +
        `━━━━━━━━━━━━━━━━━━━━━`
      )
    }
  }

  config.autoType = state === 'on'

  await reply(
    `━━━━━━━━━━━━━━━━━━━━━\n` +
    `⌨️ *AUTO TYPE*\n` +
    `━━━━━━━━━━━━━━━━━━━━━\n` +
    `${config.autoType
      ? '✅ *ON* — Bot will flex typing on every message 📖'
      : '❌ *OFF* — Typing flex disabled'}\n` +
    `━━━━━━━━━━━━━━━━━━━━━`
  )
}
