// ============================================================
//  VANGUARD MD — commands/setbotname.js
// ============================================================

const config = require('../config')

module.exports = async (ctx) => {
  const { reply, args, isSudo } = ctx
  if (!isSudo) return reply('❌ Only sudo/owner can use this command!')

  const name = args.join(' ').trim()
  if (!name) return reply('❌ Provide a new bot name!\n_Example: .setbotname VANGUARD MD_')
  if (name.length > 50) return reply('❌ Name too long! Maximum 50 characters.')

  const oldName = config.botName
  config.botName = name

  await reply(`
━━━━━━━━━━━━━━━━━━━━━
🤖 *BOT NAME UPDATED*
━━━━━━━━━━━━━━━━━━━━━
📝 Old: *${oldName}*
✅ New: *${name}*
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}
