// ============================================================
//  VANGUARD MD — commands/antigroupmention.js
//  Plan B 🗿 — join stub silently pre-warns, real mention punishes
// ============================================================

const { getGroupSettings, saveGroupSettings, addWarn, resetWarns, jidToNum, isBotAdmin, isSenderAdmin } = require('../lib/utils')
const config   = require('../config')
const defaults = require('../defaults')
const logger   = require('../lib/logger')

module.exports = async (ctx) => {
  const { reply, sock, jid, fromGroup, args, isSudo } = ctx

  if (!fromGroup) return reply('❌ This command can only be used in groups!')
  if (!isSudo)    return reply('❌ Only sudo/owner can use this command!')

  const botAdmin = await isBotAdmin(sock, jid)
  if (!botAdmin) return reply(
    `❌ *I need to be an admin first!*\n` +
    `_Make me an admin before enabling antigroupmention_`
  )

  const action = args[0]?.toLowerCase()
  const state  = args[1]?.toLowerCase()

  const validActions = ['warn', 'remove', 'delete']
  const validStates  = ['on', 'off']

  if (!action || !validActions.includes(action) || !state || !validStates.includes(state)) {
    const settings = getGroupSettings(jid)
    return reply(`
❌ Usage: *.antigroupmention <action> on/off*
━━━━━━━━━━━━━━━━━━━━━
Actions:
• warn   — Warn in group (3 = kick)
• remove — Kick immediately on first mention
• delete — Notify owner silently
━━━━━━━━━━━━━━━━━━━━━
📍 Current: *${settings.antigroupmention ? 'ON' : 'OFF'}*
⚙️ Action:  *${settings.antigroupmentionAction || 'warn'}*
━━━━━━━━━━━━━━━━━━━━━
_Each group has independent settings_
_Example: .antigroupmention warn on_
`.trim())
  }

  saveGroupSettings(jid, {
    antigroupmention:       state === 'on',
    antigroupmentionAction: action,
  })

  await reply(`
━━━━━━━━━━━━━━━━━━━━━
📢 *ANTI GROUP MENTION*
━━━━━━━━━━━━━━━━━━━━━
${state === 'on'
  ? `✅ ON — Action: *${action.toUpperCase()}*\n_Members who mention this group in their status will be ${
      action === 'warn'   ? 'warned in group (3 = kick)' :
      action === 'remove' ? 'kicked immediately' :
                            'reported to owner silently'}_`
  : '❌ OFF — Group mention protection disabled'}
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}

// ── Recent joins tracker — kept for main.js compatibility ────
const recentJoins = new Map()
module.exports.recentJoins = recentJoins

setInterval(() => {
  const now = Date.now()
  for (const [key, time] of recentJoins.entries()) {
    if (now - time > 60000) recentJoins.delete(key)
  }
}, 60000)

// ── Canonical digits-only normalizer ─────────────────────────
const toPhoneNum = (raw) => {
  if (!raw) return ''
  return raw
    .replace(/:[0-9]+@/, '@')
    .replace(/@.*/, '')
    .replace(/[^0-9]/g, '')
    .trim()
}

const resolveSenderLid = async (sock, rawSender, jid) => {
  if (!rawSender) return rawSender
  if (!rawSender.endsWith('@lid')) return rawSender

  try {
    const meta       = await sock.groupMetadata(jid)
    const rawLidBase = rawSender.split('@')[0]
    const rawLidNum  = rawLidBase.split(':')[0]

    const lidMatch = meta.participants.find(p => {
      if (!p.lid) return false
      const pLidBase = p.lid.split('@')[0]
      const pLidNum  = pLidBase.split(':')[0]
      return pLidBase === rawLidBase || pLidNum === rawLidNum
    })
    if (lidMatch?.id) {
      const resolved = lidMatch.id.replace(/:[0-9]+@/, '@')
      logger.info(`📢 @lid resolved → ${resolved}`)
      return resolved
    }

    const idMatch = meta.participants.find(p => {
      const pIdNum = p.id ? p.id.split('@')[0].split(':')[0] : ''
      return pIdNum === rawLidNum
    })
    if (idMatch?.id) {
      const resolved = idMatch.id.replace(/:[0-9]+@/, '@')
      logger.info(`📢 @lid resolved via id → ${resolved}`)
      return resolved
    }

    const participantLid = meta.participants.find(p => {
      if (!p.lid) return false
      const pLidNum = p.lid.split('@')[0].split(':')[0]
      return pLidNum === rawLidNum
    })
    if (participantLid?.lid) {
      logger.info(`📢 Non-contact — using participant lid: ${participantLid.lid}`)
      return participantLid.lid
    }
  } catch (err) {
    logger.error(`📢 resolveSenderLid error: ${err.message}`)
  }

  return rawSender
}

const buildSenderDisplay = (resolvedSender) => {
  if (!resolvedSender) return { senderNum: 'unknown', senderPhone: null, kickJid: null, warnKey: 'unknown' }

  if (resolvedSender.endsWith('@lid')) {
    const lidNum = resolvedSender.split('@')[0].split(':')[0].replace(/[^0-9]/g, '')
    return {
      senderNum:   lidNum,
      senderPhone: resolvedSender,
      kickJid:     resolvedSender,
      warnKey:     lidNum,
    }
  }

  const num = jidToNum(resolvedSender)
  return {
    senderNum:   num,
    senderPhone: num + '@s.whatsapp.net',
    kickJid:     num + '@s.whatsapp.net',
    warnKey:     num,
  }
}

module.exports.enforceCard = async (sock, msg, jid) => {
  try {
    const m           = msg.message || {}
    let detected      = false
    let sender        = null
    let senderIsAdmin = false

    // ── DETECTOR 1: stubType 27 ───────────────────────────────
    // Plan B 🗿 — join stub fires stubType 27 with JSON param
    // Instead of ignoring it, we silently pre-warn the joiner
    // so their first REAL mention hits count 2 = punished
    // delete mode: no pre-warn needed, card delete is enough
    if (msg.messageStubType === 27) {
      const raw = (msg.messageStubParameters?.[0] || '').trim()
      if (raw.startsWith('{')) {
        try {
          const param     = JSON.parse(raw)
          const rawSender = param.phoneNumber || null
          senderIsAdmin   = param.admin === 'admin' || param.admin === 'superadmin'

          if (rawSender && !senderIsAdmin) {
            const senderNum = toPhoneNum(rawSender)
            const settings  = getGroupSettings(jid)

            // Only pre-warn if antigroupmention is ON and not delete mode
            if (settings.antigroupmention && settings.antigroupmentionAction !== 'delete') {
              addWarn(jid, senderNum, 'antigroupmention-prejoin')
              logger.info(`📢 [D1-STUB27] PRE-WARN registered for joiner: ${senderNum}`)
            }
          }
        } catch (_) {}
      } else {
        // Plain JID = leave/remove system event — always ignore
        logger.info(`📢 [D1-STUB27] IGNORED — plain JID: ${raw}`)
      }
      // stub27 is NEVER a real mention — always return after handling
      return
    }

    // ── DETECTOR 2: groupStatusMentionMessage (2025+) ─────────
    // Its presence in a group message IS the detection —
    // enforceCard is only ever called for group JIDs.
    if (!detected && m.groupStatusMentionMessage) {
      detected = true
      sender   = msg.key.participant || msg.participant || msg.key.remoteJid
      logger.info(`📢 [D2-STATUSMENTION] ${jid} | sender raw: ${sender}`)
    }

    // ── DETECTOR 3: contextInfo.groupMentions (legacy) ────────
    if (!detected) {
      const contextInfo = (
        m.extendedTextMessage?.contextInfo                ||
        m.imageMessage?.contextInfo                       ||
        m.videoMessage?.contextInfo                       ||
        m.groupStatusMentionMessage?.message?.contextInfo ||
        null
      )
      const groupMentions = contextInfo?.groupMentions || []
      if (groupMentions.some(gm => gm.groupJid === jid)) {
        detected = true
        sender   = msg.key.participant || msg.participant || msg.key.remoteJid
        logger.info(`📢 [D3-LEGACY] ${jid} | sender: ${sender}`)
      }
    }

    // ── DETECTOR 4: protocolMessage type 25 ───────────────────
    if (!detected && m.protocolMessage?.type === 25) {
      detected = true
      sender   = msg.key.participant || msg.participant || msg.key.remoteJid
      logger.info(`📢 [D4-PROTO25] ${jid} | sender: ${sender}`)
    }

    if (!detected || !sender) return

    const settings = getGroupSettings(jid)
    if (!settings.antigroupmention) return

    const botAdmin = await isBotAdmin(sock, jid)
    if (!botAdmin) return

    const resolvedSender = await resolveSenderLid(sock, sender, jid)

    if (!senderIsAdmin) {
      senderIsAdmin = await isSenderAdmin(sock, jid, resolvedSender)
    }
    if (senderIsAdmin) return

    const { senderNum, senderPhone, kickJid, warnKey } = buildSenderDisplay(resolvedSender)
    const action   = settings.antigroupmentionAction || 'warn'
    const ownerJid = (config.ownerNumber || defaults.ownerNumber) + '@s.whatsapp.net'

    logger.info(`📢 Enforcing ${action} | display: ${senderNum} | kick: ${kickJid} | warnKey: ${warnKey}`)

    // ── Delete the status mention card ────────────────────────
    try {
      await sock.sendMessage(jid, {
        delete: {
          remoteJid:   jid,
          id:          msg.key.id,
          fromMe:      false,
          participant: msg.key.participant || sender,
        }
      })
    } catch (_) {}

    await new Promise(r => setTimeout(r, 500))

    // ════════════════════════════════════════════════════════
    //  REMOVE — warn2 clown 🗿
    //  Pre-warn on join = count 1 (silent)
    //  Real mention = count 2 = kick + public banner
    // ════════════════════════════════════════════════════════
    if (action === 'remove') {
      const newCount = addWarn(jid, warnKey, 'antigroupmention')

      if (newCount < 2) {
        // count 1 = existing member first real mention, silent strike
        logger.info(`📢 REMOVE silent strike on ${warnKey} count: ${newCount}`)
      } else {
        // count 2+ = kick (new member had pre-warn, existing member had silent strike)
        resetWarns(jid, warnKey)
        try {
          await sock.groupParticipantsUpdate(jid, [kickJid], 'remove')
          await sock.sendMessage(jid, {
            text:
              `🚫 *@${senderNum} has been removed!*\n` +
              `━━━━━━━━━━━━━━━━━━━━━\n` +
              `📢 Reason: Mentioning this group in their status\n` +
              `━━━━━━━━━━━━━━━━━━━━━\n` +
              `_This group does not allow public status mentions._`,
            mentions: [senderPhone],
          })
        } catch (_) {
          await sock.sendMessage(jid, {
            text:
              `⚠️ *@${senderNum} mentioned this group in their status.*\n` +
              `━━━━━━━━━━━━━━━━━━━━━\n` +
              `❌ Could not remove — please kick manually.`,
            mentions: [senderPhone],
          })
        }
      }

    // ════════════════════════════════════════════════════════
    //  WARN — 3 strike system
    //  New members: join pre-warn = count 1 (silent)
    //               1st mention  = count 2 → display Warning 1/3
    //               2nd mention  = count 3 → display Warning 2/3
    //               3rd mention  = count 4 → kick
    //  Old members: 1st mention  = count 1 (silent)
    //               2nd mention  = count 2 → display Warning 1/3
    //               3rd mention  = count 3 → display Warning 2/3
    //               4th mention  = count 4 → kick
    //  Fair for both 🗿
    // ════════════════════════════════════════════════════════
    } else if (action === 'warn') {
      const newCount = addWarn(jid, warnKey, 'antigroupmention')

      if (newCount === 1) {
        logger.info(`📢 Silent strike 1 on ${warnKey}`)

      } else if (newCount >= 4) {
        resetWarns(jid, warnKey)
        try {
          await sock.groupParticipantsUpdate(jid, [kickJid], 'remove')
          await sock.sendMessage(jid, {
            text:
              `🚨 @${senderNum} removed after *3 warnings*\n` +
              `📢 Reason: Mentioning this group in their status`,
            mentions: [senderPhone],
          })
        } catch (_) {
          await sock.sendMessage(jid, {
            text:
              `🚨 @${senderNum} reached *3 warnings* for mentioning this group in status.\n` +
              `_Could not remove — please do so manually._`,
            mentions: [senderPhone],
          })
        }

      } else {
        const displayCount = newCount - 1
        await sock.sendMessage(jid, {
          text:
            `⚠️ *Warning ${displayCount}/3* — @${senderNum}\n` +
            `📢 Do not mention this group in your status!\n` +
            `${displayCount === 2 ? '_⚠️ One more violation = removal_' : ''}`,
          mentions: [senderPhone],
        })
      }

    // ════════════════════════════════════════════════════════
    //  DELETE — silent owner DM only, no pre-warn involved
    // ════════════════════════════════════════════════════════
    } else if (action === 'delete') {
      await sock.sendMessage(ownerJid, {
        text:
          `📢 *Group Mention Alert*\n` +
          `━━━━━━━━━━━━━━━━━━━━━\n` +
          `👤 @${senderNum} mentioned this group in their status\n` +
          `━━━━━━━━━━━━━━━━━━━━━\n` +
          `_Card deleted — silent mode_`,
        mentions: [senderPhone],
      })
    }

  } catch (err) {
    logger.error(`📢 enforceCard error: ${err.message}`)
  }
}
