// ============================================================
//  VANGUARD MD — commands/antisticker.js
// ============================================================

const { saveGroupSettings, getGroupSettings, isBotAdmin, isSenderAdmin, addWarn, resetWarns, jidToNum } = require('../lib/utils')

module.exports = async (ctx) => {
  const { reply, jid, fromGroup, args, isSudo } = ctx

  if (!fromGroup) return reply('❌ This command can only be used in groups!')
  if (!isSudo) return reply('❌ Only sudo/owner can use this command!')

  const action = args[0]?.toLowerCase()
  const state  = args[1]?.toLowerCase()

  const validActions = ['warn', 'delete', 'remove']
  const validStates  = ['on', 'off']

  if (!action || !validActions.includes(action) || !state || !validStates.includes(state)) {
    const settings = getGroupSettings(jid)
    return reply(`
❌ Usage: *.antisticker <action> on/off*
━━━━━━━━━━━━━━━━━━━━━
Actions:
• warn — Delete + add strike (3 = kick)
• delete — Just delete the sticker
• remove — Delete + remove sender
━━━━━━━━━━━━━━━━━━━━━
📍 Current: *${settings.antisticker ? 'ON' : 'OFF'}*
⚙️ Action: *${settings.antistickerAction || 'warn'}*
━━━━━━━━━━━━━━━━━━━━━
_Example: .antisticker warn on_
`.trim())
  }

  saveGroupSettings(jid, {
    antisticker:       state === 'on',
    antistickerAction: action,
  })

  await reply(`
━━━━━━━━━━━━━━━━━━━━━
🎭 *ANTI STICKER*
━━━━━━━━━━━━━━━━━━━━━
${state === 'on'
  ? `✅ ON — Action: *${action.toUpperCase()}*\n_Stickers from non-admins will be ${
      action === 'warn'   ? 'deleted and warned (3 = kick)' :
      action === 'delete' ? 'deleted silently' :
                            'deleted and user removed'}_`
  : '❌ OFF — Stickers are now allowed'}
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}

// ── Enforcer — called from main.js on every group message ─────
module.exports.enforce = async (sock, msg, jid, sender) => {
  try {
    const settings = getGroupSettings(jid)
    if (!settings.antisticker) return

    // ── Detect sticker — handle viewOnce stickers too ─────
    const m = msg.message || {}
    const isSticker = (
      m.stickerMessage ||
      m.viewOnceMessage?.message?.stickerMessage ||
      m.viewOnceMessageV2?.message?.stickerMessage
    )
    if (!isSticker) return

    const botAdmin = await isBotAdmin(sock, jid)
    if (!botAdmin) return

    const senderAdmin = await isSenderAdmin(sock, jid, sender)
    if (senderAdmin) return

    const action    = settings.antistickerAction || 'warn'
    const senderNum = jidToNum(sender)

    // ── Always delete the sticker first ───────────────────
    try { await sock.sendMessage(jid, { delete: msg.key }) } catch (_) {}

    // ── warn: strike + auto-kick at 3 ─────────────────────
    if (action === 'warn') {
      const newCount = addWarn(jid, senderNum, 'antisticker')

      if (newCount >= 3) {
        resetWarns(jid, senderNum)
        try {
          await sock.groupParticipantsUpdate(jid, [sender], 'remove')
          await sock.sendMessage(jid, {
            text:     `🚨 @${senderNum} has been removed after *3 warnings* for sending stickers.`,
            mentions: [sender],
          })
        } catch (_) {
          await sock.sendMessage(jid, {
            text:     `🚨 @${senderNum} reached *3 warnings* for sending stickers. Could not remove — please do so manually.`,
            mentions: [sender],
          })
        }
      } else {
        await sock.sendMessage(jid, {
          text:
            `⚠️ *Warning ${newCount}/3* — @${senderNum}\n` +
            `🎭 Stickers are not allowed in this group!\n` +
            `${newCount === 2 ? '_⚠️ One more violation = removal_' : ''}`,
          mentions: [sender],
        })
      }

    // ── delete: silent delete + notification ──────────────
    } else if (action === 'delete') {
      await sock.sendMessage(jid, {
        text:     `🎭 @${senderNum} stickers are not allowed in this group!`,
        mentions: [sender],
      })

    // ── remove: instant kick ──────────────────────────────
    } else if (action === 'remove') {
      try {
        await sock.groupParticipantsUpdate(jid, [sender], 'remove')
        await sock.sendMessage(jid, {
          text:     `🚫 @${senderNum} was removed for sending a sticker.`,
          mentions: [sender],
        })
      } catch (_) {}
    }

  } catch (err) {
    require('../lib/logger').error(`🎭 Antisticker enforce error: ${err.message}`)
  }
}
