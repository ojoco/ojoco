// ============================================================
//  VANGUARD MD — commands/admins.js
// ============================================================

module.exports = async (ctx) => {
  const { reply, sock, jid, fromGroup } = ctx

  if (!fromGroup) return reply('❌ This command can only be used in groups!')

  try {
    const meta = await sock.groupMetadata(jid)
    const admins = meta.participants.filter(
      p => p.admin === 'admin' || p.admin === 'superadmin'
    )

    if (!admins.length) return reply('❌ No admins found in this group!')

    const list = admins.map((p, i) => {
      const num = p.id.split('@')[0]
      const role = p.admin === 'superadmin' ? '👑 Owner' : '⭐ Admin'
      return `${role}: +${num}`
    }).join('\n')

    const mentions = admins.map(p => p.id)

    await reply({
      text: `
━━━━━━━━━━━━━━━━━━━━━
⭐ *GROUP ADMINS*
━━━━━━━━━━━━━━━━━━━━━
📛 Group: *${meta.subject}*
⭐ Total Admins: *${admins.length}*
━━━━━━━━━━━━━━━━━━━━━
${list}
━━━━━━━━━━━━━━━━━━━━━
`.trim(),
      mentions,
    })
  } catch (err) {
    await reply(`❌ Failed to fetch admins: ${err.message}`)
  }
}
