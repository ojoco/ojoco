// ============================================================
//  VANGUARD MD — commands/warn.js
// ============================================================

const { isBotAdmin, isSenderAdmin, getWarnCount, setWarnCount, jidToNum } = require('../lib/utils')

const MAX_WARNS = 3

module.exports = async (ctx) => {
  const { reply, sock, jid, fromGroup, sender, mentions, quoted, args, isSudo } = ctx

  if (!fromGroup) return reply('❌ This command can only be used in groups!')
  if (!isSudo) return reply('❌ Only sudo/owner can use this command!')

  const botAdmin = await isBotAdmin(sock, jid)
  if (!botAdmin) return reply('❌ I need to be an admin to warn members!')

  // Get target
  let target = mentions?.[0] || null
  if (!target && quoted?.sender) target = quoted.sender
  if (!target) return reply('❌ Mention or reply to someone to warn!\n_Example: .warn @user_')

  if (target === sender) return reply('❌ You cannot warn yourself!')

  const targetAdmin = await isSenderAdmin(sock, jid, target)
  if (targetAdmin) return reply('❌ Cannot warn an admin!')

  const targetNum = jidToNum(target)
  const reason = args.join(' ').replace(/@\d+/g, '').trim() || 'No reason provided'

  const current = getWarnCount(jid, targetNum)
  const newCount = current + 1
  setWarnCount(jid, targetNum, newCount)

  if (newCount >= MAX_WARNS) {
    // Auto kick on max warns
    setWarnCount(jid, targetNum, 0)
    try {
      await sock.groupParticipantsUpdate(jid, [target], 'remove')
    } catch (_) {}

    return reply({
      text: `
━━━━━━━━━━━━━━━━━━━━━
🚨 *MAX WARNINGS REACHED*
━━━━━━━━━━━━━━━━━━━━━
👤 @${targetNum} has been *kicked!*
⚠️ Reached maximum of *${MAX_WARNS} warnings*
📝 Last reason: _${reason}_
━━━━━━━━━━━━━━━━━━━━━
`.trim(),
      mentions: [target],
    })
  }

  await reply({
    text: `
━━━━━━━━━━━━━━━━━━━━━
⚠️ *WARNING ISSUED*
━━━━━━━━━━━━━━━━━━━━━
👤 @${targetNum}
📝 Reason: _${reason}_
━━━━━━━━━━━━━━━━━━━━━
🔢 Warnings: *${newCount}/${MAX_WARNS}*
${newCount === MAX_WARNS - 1 ? '🚨 *One more warning = kick!*' : ''}
━━━━━━━━━━━━━━━━━━━━━
`.trim(),
    mentions: [target],
  })
}
