// ============================================================
//  VANGUARD MD — commands/didyk.js
//  Did You Know — random facts
// ============================================================

const axios = require('axios')

module.exports = async (ctx) => {
  const { sock, msg, jid, reply } = ctx

  try {
    const { data } = await axios.get(
      'https://uselessfacts.jsph.pl/random.json?language=en',
      { timeout: 10000 }
    )

    await sock.sendMessage(jid, {
      text:
        '🧠 *DID YOU KNOW?*\n' +
        '━━━━━━━━━━━━━━━━━━━━━\n\n' +
        data.text + '\n\n' +
        '━━━━━━━━━━━━━━━━━━━━━\n' +
        '> _Powered by VANGUARD MD_ ',
    }, { quoted: msg })

  } catch (err) {
    await reply('❌ Could not fetch a fact right now. Try again!')
  }
}
