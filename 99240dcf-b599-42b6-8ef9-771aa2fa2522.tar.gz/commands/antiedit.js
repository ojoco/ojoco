// ============================================================
//  VANGUARD MD — commands/antiedit.js
// ============================================================

const config = require('../config')

module.exports = async (ctx) => {
  const { reply, args, isSudo } = ctx
  if (!isSudo) return reply('❌ Only sudo/owner can use this command!')

  const state = args[0]?.toLowerCase()
  if (!state || !['on', 'off'].includes(state)) {
    return reply(`❌ Usage: *.antiedit on/off*\n📍 Current: *${config.antiedit ? 'ON' : 'OFF'}*`)
  }

  config.antiedit = state === 'on'

  await reply(`
━━━━━━━━━━━━━━━━━━━━━
✏️ *ANTI EDIT*
━━━━━━━━━━━━━━━━━━━━━
${config.antiedit
  ? '✅ ON — Edited messages will be forwarded to owner inbox with original'
  : '❌ OFF — Edited messages will be ignored'}
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}
