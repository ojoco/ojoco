// ============================================================
//  VANGUARD MD — commands/antibadword.js
// ============================================================

const { saveGroupSettings, getGroupSettings, isBotAdmin, isSenderAdmin, addWarn, resetWarns, jidToNum, readData } = require('../lib/utils')

module.exports = async (ctx) => {
  const { reply, jid, fromGroup, args, isSudo } = ctx

  if (!fromGroup) return reply('❌ This command can only be used in groups!')
  if (!isSudo) return reply('❌ Only sudo/owner can use this command!')

  const action = args[0]?.toLowerCase()
  const state  = args[1]?.toLowerCase()

  const validActions = ['warn', 'delete', 'remove']
  const validStates  = ['on', 'off']

  if (!action || !validActions.includes(action) || !state || !validStates.includes(state)) {
    const settings = getGroupSettings(jid)
    return reply(`
❌ Usage: *.antibadword <action> on/off*
━━━━━━━━━━━━━━━━━━━━━
Actions:
• warn — Delete + add strike (3 = kick)
• delete — Just delete the message
• remove — Delete + remove sender
━━━━━━━━━━━━━━━━━━━━━
📍 Current: *${settings.antibadword ? 'ON' : 'OFF'}*
⚙️ Action: *${settings.antibadwordAction || 'warn'}*
━━━━━━━━━━━━━━━━━━━━━
💡 Add words with *.addbadword <word>*
_Example: .antibadword warn on_
`.trim())
  }

  saveGroupSettings(jid, {
    antibadword:       state === 'on',
    antibadwordAction: action,
  })

  await reply(`
━━━━━━━━━━━━━━━━━━━━━
🤬 *ANTI BAD WORD*
━━━━━━━━━━━━━━━━━━━━━
${state === 'on'
  ? `✅ ON — Action: *${action.toUpperCase()}*\n_Bad words from non-admins will be ${
      action === 'warn'   ? 'deleted and warned (3 = kick)' :
      action === 'delete' ? 'deleted silently' :
                            'deleted and user removed'}_`
  : '❌ OFF — Bad word filter disabled'}
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}

// ── Enforcer ──────────────────────────────────────────────────
module.exports.enforce = async (sock, msg, jid, sender) => {
  try {
    const settings = getGroupSettings(jid)
    if (!settings.antibadword) return

    const body = (
      msg.message?.conversation ||
      msg.message?.extendedTextMessage?.text ||
      msg.message?.imageMessage?.caption ||
      msg.message?.videoMessage?.caption || ''
    ).toLowerCase()

    if (!body) return

    // ── Load default + group custom bad words ─────────────
    const defaultWords = readData('badwords.json')
    const customWords  = settings.customBadWords || []
    const allBadWords  = [...new Set([...defaultWords, ...customWords])]

    const found = allBadWords.find(word => body.includes(word.toLowerCase()))
    if (!found) return

    const botAdmin = await isBotAdmin(sock, jid)
    if (!botAdmin) return

    const senderAdmin = await isSenderAdmin(sock, jid, sender)
    if (senderAdmin) return

    const action    = settings.antibadwordAction || 'warn'
    const senderNum = jidToNum(sender)

    // ── Always delete the message first ───────────────────
    try { await sock.sendMessage(jid, { delete: msg.key }) } catch (_) {}

    // ── warn: strike + auto-kick at 3 ─────────────────────
    if (action === 'warn') {
      const newCount = addWarn(jid, senderNum, 'antibadword')

      if (newCount >= 3) {
        resetWarns(jid, senderNum)
        try {
          await sock.groupParticipantsUpdate(jid, [sender], 'remove')
          await sock.sendMessage(jid, {
            text:     `🚨 @${senderNum} has been removed after *3 warnings* for bad language.`,
            mentions: [sender],
          })
        } catch (_) {
          await sock.sendMessage(jid, {
            text:     `🚨 @${senderNum} reached *3 warnings* for bad language. Could not remove — please do so manually.`,
            mentions: [sender],
          })
        }
      } else {
        await sock.sendMessage(jid, {
          text:
            `⚠️ *Warning ${newCount}/3* — @${senderNum}\n` +
            `🤬 Watch your language!\n` +
            `${newCount === 2 ? '_⚠️ One more violation = removal_' : ''}`,
          mentions: [sender],
        })
      }

    // ── delete: silent delete + notification ──────────────
    } else if (action === 'delete') {
      await sock.sendMessage(jid, {
        text:     `🤬 @${senderNum} that language is not allowed here!`,
        mentions: [sender],
      })

    // ── remove: instant kick ──────────────────────────────
    } else if (action === 'remove') {
      try {
        await sock.groupParticipantsUpdate(jid, [sender], 'remove')
        await sock.sendMessage(jid, {
          text:     `🚫 @${senderNum} was removed for using bad language.`,
          mentions: [sender],
        })
      } catch (_) {}
    }

  } catch (err) {
    require('../lib/logger').error(`🤬 Antibadword enforce error: ${err.message}`)
  }
}
