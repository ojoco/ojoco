// ============================================================
//  VANGUARD MD — commands/morse.js
// ============================================================

const MORSE_CODE = {
  A: '.-',   B: '-...', C: '-.-.', D: '-..',  E: '.',
  F: '..-.', G: '--.',  H: '....', I: '..',   J: '.---',
  K: '-.-',  L: '.-..', M: '--',   N: '-.',   O: '---',
  P: '.--.', Q: '--.-', R: '.-.',  S: '...',  T: '-',
  U: '..-',  V: '...-', W: '.--',  X: '-..-', Y: '-.--',
  Z: '--..',
  0: '-----', 1: '.----', 2: '..---', 3: '...--', 4: '....-',
  5: '.....', 6: '-....', 7: '--...', 8: '---..', 9: '----.',
  '.': '.-.-.-', ',': '--..--', '?': '..--..', "'": '.----.',
  '!': '-.-.--', '/': '-..-.', '(': '-.--.', ')': '-.--.-',
  '&': '.-...', ':': '---...', ';': '-.-.-.', '=': '-...-',
  '+': '.-.-.', '-': '-....-', '_': '..--.-', '"': '.-..-.',
  '$': '...-..-', '@': '.--.-.', ' ': '/',
}

const REVERSE_MORSE = Object.fromEntries(
  Object.entries(MORSE_CODE).map(([k, v]) => [v, k])
)

module.exports = async (ctx) => {
  const { reply, args } = ctx

  if (!args.length) {
    return reply('❌ Provide text to convert!\n_Example: .morse Hello World_\n_Or decode: .morse ... --- ..._')
  }

  const input = args.join(' ').toUpperCase()

  // Detect if input is morse (contains dots and dashes)
  const isMorse = /^[.\- /]+$/.test(input.trim())

  if (isMorse) {
    // Decode morse to text
    try {
      const decoded = input
        .split(' / ')
        .map(word =>
          word.split(' ')
            .map(code => REVERSE_MORSE[code] || '?')
            .join('')
        )
        .join(' ')

      await reply(`
📡 *MORSE DECODE*
━━━━━━━━━━━━━━━━━━━━━
📥 Morse: _${input.length > 60 ? input.slice(0, 60) + '...' : input}_
━━━━━━━━━━━━━━━━━━━━━
📤 Text: *${decoded}*
━━━━━━━━━━━━━━━━━━━━━
`.trim())
    } catch {
      await reply('❌ Invalid morse code!')
    }
    return
  }

  // Encode text to morse
  if (input.length > 100) {
    return reply('❌ Text too long! Maximum 100 characters.')
  }

  const unsupported = []
  const morse = input
    .split('')
    .map(char => {
      if (MORSE_CODE[char] !== undefined) return MORSE_CODE[char]
      unsupported.push(char)
      return '?'
    })
    .join(' ')

  await reply(`
📡 *TEXT TO MORSE*
━━━━━━━━━━━━━━━━━━━━━
📥 Text: _${input}_
━━━━━━━━━━━━━━━━━━━━━
📤 Morse:
\`${morse}\`
━━━━━━━━━━━━━━━━━━━━━
${unsupported.length ? `⚠️ Unsupported chars: *${[...new Set(unsupported)].join(', ')}*` : '✅ All characters converted!'}
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}
