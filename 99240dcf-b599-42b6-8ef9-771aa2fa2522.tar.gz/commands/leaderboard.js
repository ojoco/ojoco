// ============================================================
//  VANGUARD MD — commands/leaderboard.js
// ============================================================

const { getEconomy, jidToNum } = require('../lib/utils')

const medals = ['🥇', '🥈', '🥉', '4️⃣', '5️⃣', '6️⃣', '7️⃣', '8️⃣', '9️⃣', '🔟']

module.exports = async (ctx) => {
  const { reply } = ctx

  const data = getEconomy()

  if (!data || Object.keys(data).length === 0) {
    return reply('❌ No economy data yet! Start with *.daily* or *.work*')
  }

  // Sort by balance descending
  const sorted = Object.entries(data)
    .map(([num, acc]) => ({ num, balance: acc.balance || 0 }))
    .sort((a, b) => b.balance - a.balance)
    .slice(0, 10)

  const rows = sorted
    .map((entry, i) => `${medals[i]} *+${entry.num}*\n    💵 $${entry.balance.toLocaleString()}`)
    .join('\n\n')

  await reply(`
━━━━━━━━━━━━━━━━━━━━━
🏆 *ECONOMY LEADERBOARD*
━━━━━━━━━━━━━━━━━━━━━
${rows}
━━━━━━━━━━━━━━━━━━━━━
💡 Earn more with *.daily* and *.work*
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}
