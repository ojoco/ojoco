// ============================================================
//  VANGUARD MD — commands/autoreactstatus.js
// ============================================================

const config = require('../config')
const defaults = require('../defaults')

module.exports = async (ctx) => {
  const { reply, args, isSudo } = ctx
  if (!isSudo) return reply('❌ Only sudo/owner can use this command!')

  const state = args[0]?.toLowerCase()
  if (!state || !['on', 'off'].includes(state)) {
    const current = config.autoReactStatus ?? defaults.autoReactStatus
    const emojis = (config.statusEmojis || defaults.statusEmojis).join(' ')
    return reply(`
❌ Usage: *.autoreactstatus on/off*
📍 Current: *${current ? 'ON' : 'OFF'}*
😀 Emojis: *${emojis}*
💡 Change emojis with *.statusemoji*
`.trim())
  }

  config.autoReactStatus = state === 'on'

  await reply(`
━━━━━━━━━━━━━━━━━━━━━
😀 *AUTO REACT STATUS*
━━━━━━━━━━━━━━━━━━━━━
${config.autoReactStatus
  ? `✅ ON — Bot will react to statuses with: *${(config.statusEmojis || defaults.statusEmojis).join(' ')}*`
  : '❌ OFF — Bot will not react to statuses'}
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}
