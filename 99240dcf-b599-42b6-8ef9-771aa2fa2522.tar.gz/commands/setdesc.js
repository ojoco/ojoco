// ============================================================
//  VANGUARD MD — commands/setdesc.js
// ============================================================

const { isBotAdmin } = require('../lib/utils')

module.exports = async (ctx) => {
  const { reply, sock, jid, fromGroup, args, isSudo } = ctx

  if (!fromGroup) return reply('❌ This command can only be used in groups!')
  if (!isSudo) return reply('❌ Only sudo/owner can use this command!')

  const botAdmin = await isBotAdmin(sock, jid)
  if (!botAdmin) return reply('❌ I need to be an admin to change the group description!')

  const newDesc = args.join(' ').trim()
  if (!newDesc) return reply('❌ Provide a new description!\n_Example: .setdesc Welcome to our group!_')
  if (newDesc.length > 512) return reply('❌ Description too long! Maximum 512 characters.')

  try {
    await sock.groupUpdateDescription(jid, newDesc)
    await reply(`✅ Group description updated successfully!`)
  } catch (err) {
    await reply(`❌ Failed to update description: ${err.message}`)
  }
}
