// ============================================================
//  VANGUARD MD — commands/unblock.js
// ============================================================

const { jidToNum } = require('../lib/utils')

module.exports = async (ctx) => {
  const { reply, sock, mentions, quoted, isOwner } = ctx
  if (!isOwner) return reply('❌ Only owner can use this command!')

  let target = mentions?.[0] || null
  if (!target && quoted?.sender) target = quoted.sender
  if (!target) return reply('❌ Mention or reply to someone to unblock!\n_Example: .unblock @user_')

  const targetNum = jidToNum(target)

  try {
    await sock.updateBlockStatus(target, 'unblock')
    await reply({
      text: `
━━━━━━━━━━━━━━━━━━━━━
✅ *USER UNBLOCKED*
━━━━━━━━━━━━━━━━━━━━━
👤 @${targetNum} has been unblocked.
━━━━━━━━━━━━━━━━━━━━━
`.trim(),
      mentions: [target],
    })
  } catch (err) {
    await reply(`❌ Failed to unblock: ${err.message}`)
  }
}
