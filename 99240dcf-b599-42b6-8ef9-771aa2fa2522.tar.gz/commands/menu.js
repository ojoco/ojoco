// ============================================================
//  VANGUARD MD — commands/menu.js
// ============================================================

const config = require('../config')
const defaults = require('../defaults')
const { formatUptime } = require('../lib/utils')

module.exports = async (ctx) => {
  const { reply, sock } = ctx
  const prefix = config.prefix || defaults.prefix
  const botName = config.botName || defaults.botName
  const mode = config.mode || defaults.mode
  const uptime = formatUptime(process.uptime())
  const time = new Date().toLocaleString('en-KE', { timeZone: 'Africa/Nairobi', hour12: true })

  const menu = `
╔═══════════════════════════╗
║     🤖 *${botName}*     ║
╚═══════════════════════════╝
⏱️ Uptime: *${uptime}*
📡 Mode: *${mode.toUpperCase()}*
🕐 Time: *${time}*
━━━━━━━━━━━━━━━━━━━━━━━━━━━

ℹ️ *INFO COMMANDS*
━━━━━━━━━━━━━━━━━━━━━━━━━━━
• ${prefix}ping — Bot speed
• ${prefix}ping2 — Detailed ping
• ${prefix}status — System info
• ${prefix}runtime — Bot uptime
• ${prefix}botstatus — Bot settings
• ${prefix}owner — Contact owner
• ${prefix}repo — Repository info
• ${prefix}userid — Your WA ID
• ${prefix}device — Device info
• ${prefix}time — Current time
• ${prefix}totalmembers — Group members

━━━━━━━━━━━━━━━━━━━━━━━━━━━
😄 *FUN COMMANDS*
━━━━━━━━━━━━━━━━━━━━━━━━━━━
• ${prefix}joke — Random joke
• ${prefix}quote — Random quote
• ${prefix}fact — Random fact
• ${prefix}truth — Truth question
• ${prefix}dare — Dare challenge
• ${prefix}meme — Text meme
• ${prefix}roast @user — Roast someone
• ${prefix}compliment @user — Compliment
• ${prefix}ship @user @user — Ship users
• ${prefix}rate <thing> — Rate 1-10
• ${prefix}8ball <question> — Magic 8ball

━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎮 *GAME COMMANDS*
━━━━━━━━━━━━━━━━━━━━━━━━━━━
• ${prefix}tictactoe @user — Play TTT
• ${prefix}move <pos> — Make a move
• ${prefix}rps <rock/paper/scissors>
• ${prefix}dice — Roll a dice
• ${prefix}coin — Flip a coin
• ${prefix}quiz — Random quiz
• ${prefix}guess — Guess a number

━━━━━━━━━━━━━━━━━━━━━━━━━━━
🛠️ *TOOLS COMMANDS*
━━━━━━━━━━━━━━━━━━━━━━━━━━━
• ${prefix}sticker — Image/video to sticker
• ${prefix}toimg — Sticker to image
• ${prefix}calculate <math> — Calculator
• ${prefix}genpass <length> — Password
• ${prefix}qrcode <text> — QR code
• ${prefix}base64 <encode/decode> <text>
• ${prefix}binary <text> — To binary
• ${prefix}morse <text> — Morse code

━━━━━━━━━━━━━━━━━━━━━━━━━━━
💰 *ECONOMY COMMANDS*
━━━━━━━━━━━━━━━━━━━━━━━━━━━
• ${prefix}balance — Check balance
• ${prefix}daily — Daily reward
• ${prefix}work — Work for money
• ${prefix}rob @user — Rob someone
• ${prefix}transfer @user <amount>
• ${prefix}leaderboard — Top users

━━━━━━━━━━━━━━━━━━━━━━━━━━━
👥 *GROUP COMMANDS*
━━━━━━━━━━━━━━━━━━━━━━━━━━━
• ${prefix}groupinfo — Group details
• ${prefix}members — List members
• ${prefix}admins — List admins
• ${prefix}tagall — Mention all
• ${prefix}hidetag — Hidden mention
• ${prefix}promote @user — Make admin
• ${prefix}demote @user — Remove admin
• ${prefix}kick @user — Remove member
• ${prefix}add <number> — Add member
• ${prefix}link — Invite link
• ${prefix}setgroupname <name>
• ${prefix}setdesc <text>
• ${prefix}poll <question|opt1|opt2>

━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚙️ *SETTINGS* _(Owner/Sudo)_
━━━━━━━━━━━━━━━━━━━━━━━━━━━
• ${prefix}public / ${prefix}private
• ${prefix}setbotname <name>
• ${prefix}setprefix <prefix>
• ${prefix}anticall on/off
• ${prefix}autoread on/off
• ${prefix}autotype on/off
• ${prefix}chatbot on/off
• ${prefix}alwaysonline on/off
• ${prefix}autoviewstatus on/off
• ${prefix}autoreactstatus on/off
• ${prefix}statusemoji <emojis>

━━━━━━━━━━━━━━━━━━━━━━━━━━━
🛡️ *PRIVACY* _(Owner/Sudo)_
━━━━━━━━━━━━━━━━━━━━━━━━━━━
• ${prefix}antidelete on/off
• ${prefix}antideletestatus on/off
• ${prefix}antiedit on/off
• ${prefix}antilink <action> on/off
• ${prefix}antigroupmention on/off
• ${prefix}antisticker <action> on/off
• ${prefix}antimedia <action> on/off
• ${prefix}antibadword <action> on/off
• ${prefix}addbadword <word>
• ${prefix}warn @user

━━━━━━━━━━━━━━━━━━━━━━━━━━━
🔧 *OWNER ONLY*
━━━━━━━━━━━━━━━━━━━━━━━━━━━
• ${prefix}broadcast <text>
• ${prefix}restart
• ${prefix}block @user
• ${prefix}unblock @user
• ${prefix}getpp @user
• ${prefix}ban @user
• ${prefix}unban @user
• ${prefix}listban
• ${prefix}unbanall
• ${prefix}vv — View view-once
• ${prefix}vv2 — Forward to inbox

━━━━━━━━━━━━━━━━━━━━━━━━━━━
> 🤖 *${botName}* | Powered by Baileys
`.trim()

  await reply({ text: menu })
}
