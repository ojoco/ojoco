// ============================================================
//  VANGUARD MD — commands/statusemoji.js
// ============================================================

const config = require('../config')
const defaults = require('../defaults')
const { isSingleEmoji } = require('../lib/utils')

// Blocked multi-codepoint emojis
const BLOCKED_EMOJIS = ['❤️‍🩹', '❤️‍🔥', '👋🏾', '🤲🏾']

module.exports = async (ctx) => {
  const { reply, args, isSudo } = ctx
  if (!isSudo) return reply('❌ Only sudo/owner can use this command!')

  if (!args.length) {
    const current = (config.statusEmojis || defaults.statusEmojis).join(' ')
    return reply(`
━━━━━━━━━━━━━━━━━━━━━
😀 *STATUS EMOJIS*
━━━━━━━━━━━━━━━━━━━━━
📍 Current: *${current}*
━━━━━━━━━━━━━━━━━━━━━
💡 Usage: *.statusemoji 💙 💚 🔥*
⚠️ Only simple single emojis allowed
❌ Blocked: skin-tone & combined emojis
━━━━━━━━━━━━━━━━━━━━━
`.trim())
  }

  // Each arg should be a single emoji
  const newEmojis = []
  const rejected = []

  for (const arg of args) {
    const trimmed = arg.trim()
    if (!trimmed) continue

    // Block explicitly blocked ones
    if (BLOCKED_EMOJIS.some(e => trimmed.includes(e))) {
      rejected.push(trimmed)
      continue
    }

    // Must be a single grapheme emoji
    if (!isSingleEmoji(trimmed)) {
      rejected.push(trimmed)
      continue
    }

    newEmojis.push(trimmed)
  }

  if (!newEmojis.length) {
    return reply(`
❌ *No valid emojis provided!*
━━━━━━━━━━━━━━━━━━━━━
⚠️ Rejected: *${rejected.join(' ')}*
━━━━━━━━━━━━━━━━━━━━━
💡 Use simple emojis like: 💙 💚 😂 🔥 ❤️ 🥰
❌ Avoid skin-tone and combined emojis
━━━━━━━━━━━━━━━━━━━━━
`.trim())
  }

  if (newEmojis.length > 5) {
    return reply('❌ Maximum *5 emojis* allowed!')
  }

  config.statusEmojis = newEmojis

  await reply(`
━━━━━━━━━━━━━━━━━━━━━
😀 *STATUS EMOJIS UPDATED*
━━━━━━━━━━━━━━━━━━━━━
✅ New Emojis: *${newEmojis.join(' ')}*
${rejected.length ? `⚠️ Rejected: *${rejected.join(' ')}*` : ''}
━━━━━━━━━━━━━━━━━━━━━
💡 Bot will now react to statuses with these emojis
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}
