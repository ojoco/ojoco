// ============================================================
//  VANGUARD MD — commands/time.js
// ============================================================

const { getNairobiTime } = require('../lib/utils')

module.exports = async (ctx) => {
  const { reply } = ctx
  const time = getNairobiTime()
  await reply(`
━━━━━━━━━━━━━━━━━━━━━
🕐 *CURRENT TIME*
━━━━━━━━━━━━━━━━━━━━━
📍 Location: *Nairobi, Kenya*
🌍 Timezone: *Africa/Nairobi (EAT)*
⏰ Time: *${time}*
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}
