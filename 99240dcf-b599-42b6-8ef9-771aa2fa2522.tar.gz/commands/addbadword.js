// ============================================================
//  VANGUARD MD — commands/addbadword.js
// ============================================================

const { saveGroupSettings, getGroupSettings } = require('../lib/utils')

module.exports = async (ctx) => {
  const { reply, jid, fromGroup, args, isSudo } = ctx

  if (!fromGroup) return reply('❌ This command can only be used in groups!')
  if (!isSudo) return reply('❌ Only sudo/owner can use this command!')

  const word = args[0]?.toLowerCase().trim()
  if (!word) return reply('❌ Provide a word to add!\n_Example: .addbadword badword_')
  if (word.length < 2) return reply('❌ Word too short! Minimum 2 characters.')
  if (word.length > 30) return reply('❌ Word too long! Maximum 30 characters.')

  const settings = getGroupSettings(jid)
  const customWords = settings.customBadWords || []

  if (customWords.includes(word)) {
    return reply(`⚠️ *"${word}"* is already in the bad word list!`)
  }

  customWords.push(word)
  saveGroupSettings(jid, { customBadWords: customWords })

  await reply(`
━━━━━━━━━━━━━━━━━━━━━
🤬 *BAD WORD ADDED*
━━━━━━━━━━━━━━━━━━━━━
✅ Added: *"${word}"*
📋 Total custom words: *${customWords.length}*
━━━━━━━━━━━━━━━━━━━━━
💡 Enable filter with *.antibadword warn on*
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}
