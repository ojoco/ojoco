// ============================================================
//  VANGUARD MD — commands/balance.js
// ============================================================

const { getBalance, jidToNum } = require('../lib/utils')

module.exports = async (ctx) => {
  const { reply, sender, mentions, quoted } = ctx

  // Check own or mentioned user balance
  let target = sender
  let targetNum = jidToNum(sender)
  let isSelf = true

  if (mentions?.[0]) {
    target = mentions[0]
    targetNum = jidToNum(target)
    isSelf = false
  } else if (quoted?.sender) {
    target = quoted.sender
    targetNum = jidToNum(target)
    isSelf = false
  }

  const account = getBalance(targetNum)

  await reply({
    text: `
━━━━━━━━━━━━━━━━━━━━━
💰 *BALANCE*
━━━━━━━━━━━━━━━━━━━━━
👤 User: @${targetNum}
━━━━━━━━━━━━━━━━━━━━━
💵 Balance: *$${account.balance.toLocaleString()}*
━━━━━━━━━━━━━━━━━━━━━
${isSelf ? '💡 Earn more with *.daily* and *.work*' : ''}
`.trim(),
    mentions: [target],
  })
}
