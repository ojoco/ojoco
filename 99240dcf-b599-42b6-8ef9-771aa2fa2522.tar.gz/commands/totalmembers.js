// ============================================================
//  VANGUARD MD — commands/totalmembers.js
// ============================================================

module.exports = async (ctx) => {
  const { reply, sock, jid, fromGroup } = ctx

  if (!fromGroup) {
    await reply('❌ This command can only be used in groups!')
    return
  }

  try {
    const meta = await sock.groupMetadata(jid)
    const all = meta.participants
    const admins = all.filter(p => p.admin === 'admin' || p.admin === 'superadmin')
    const superAdmins = all.filter(p => p.admin === 'superadmin')
    const regular = all.filter(p => !p.admin)

    await reply(`
━━━━━━━━━━━━━━━━━━━━━
👥 *GROUP MEMBERS*
━━━━━━━━━━━━━━━━━━━━━
📛 Group: *${meta.subject}*
━━━━━━━━━━━━━━━━━━━━━
👤 Total Members: *${all.length}*
👑 Super Admins: *${superAdmins.length}*
⭐ Admins: *${admins.length}*
🙋 Regular: *${regular.length}*
━━━━━━━━━━━━━━━━━━━━━
`.trim())
  } catch (err) {
    await reply(`❌ Failed to fetch group info: ${err.message}`)
  }
}
