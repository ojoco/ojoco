// ============================================================
//  VANGUARD MD — commands/anime.js
//  Anime reactions — stickers, images, quotes
// ============================================================

const axios  = require('axios')
const fs     = require('fs')
const path   = require('path')
const { exec }   = require('child_process')
const { tmpdir } = require('os')

const ANIMU_BASE = 'https://api.some-random-api.com/animu'

const SUPPORTED = ['nom', 'poke', 'cry', 'kiss', 'pat', 'hug', 'wink', 'face-palm', 'quote']

const normalizeType = (input) => {
  const lower = (input || '').toLowerCase()
  if (lower === 'facepalm' || lower === 'face_palm') return 'face-palm'
  return lower
}

const convertToSticker = (inputPath, outputPath, isAnimated) => {
  return new Promise((resolve, reject) => {
    const filter = isAnimated
      ? 'scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000,fps=15'
      : 'scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000'
    exec(
      `ffmpeg -y -i "${inputPath}" -vf "${filter}" -c:v libwebp -preset default -loop 0 -vsync 0 -pix_fmt yuva420p -quality 75 -compression_level 6 "${outputPath}"`,
      (err) => err ? reject(err) : resolve()
    )
  })
}

module.exports = async (ctx) => {
  const { sock, msg, jid, args, reply } = ctx

  const sub = normalizeType(args[0] || '')

  if (!sub) return reply(
    '🎌 *ANIME REACTIONS*\n' +
    '━━━━━━━━━━━━━━━━━━━━━\n' +
    '_Usage: .anime <type>_\n\n' +
    '*Types:*\n' +
    SUPPORTED.join(', ')
  )

  if (!SUPPORTED.includes(sub)) return reply(
    '❌ Unsupported type: *' + sub + '*\n\n' +
    '*Available:* ' + SUPPORTED.join(', ')
  )

  try {
    const { data } = await axios.get(ANIMU_BASE + '/' + sub, { timeout: 15000 })

    // ── Quote type — send as text ─────────────────────────
    if (data.quote) {
      return await reply(
        '🎌 *Anime Quote*\n' +
        '━━━━━━━━━━━━━━━━━━━━━\n\n' +
        data.quote
      )
    }

    // ── Media type — gif → sticker, image → image ─────────
    if (data.link) {
      const link  = data.link
      const lower = link.toLowerCase()
      const isGif = lower.endsWith('.gif')
      const isImg = /\.(jpg|jpeg|png|webp)$/.test(lower)

      const { data: mediaData } = await axios.get(link, {
        responseType: 'arraybuffer',
        timeout: 15000,
        headers: { 'User-Agent': 'Mozilla/5.0' },
      })
      const mediaBuf = Buffer.from(mediaData)

      // ── GIF → webp sticker via ffmpeg ─────────────────
      if (isGif) {
        const ts      = Date.now()
        const gifPath = path.join(tmpdir(), `vanguard_anime_${ts}.gif`)
        const webpPath = path.join(tmpdir(), `vanguard_anime_${ts}.webp`)

        try {
          fs.writeFileSync(gifPath, mediaBuf)
          await convertToSticker(gifPath, webpPath, true)
          const stickerBuf = fs.readFileSync(webpPath)
          await sock.sendMessage(jid, { sticker: stickerBuf }, { quoted: msg })
        } finally {
          try { fs.unlinkSync(gifPath)  } catch (_) {}
          try { fs.unlinkSync(webpPath) } catch (_) {}
        }
        return
      }

      // ── Static image → send as image ──────────────────
      if (isImg) {
        await sock.sendMessage(jid, {
          image:   mediaBuf,
          caption: '🎌 *' + sub.toUpperCase() + '*',
        }, { quoted: msg })
        return
      }
    }

    await reply('❌ Failed to fetch anime reaction. Try again!')

  } catch (err) {
    await reply('❌ An error occurred: ' + err.message)
  }
}
