// ============================================================
//  VANGUARD MD — commands/broadcast.js
// ============================================================

const { jidToNum } = require('../lib/utils')

module.exports = async (ctx) => {
  const { reply, sock, args, isOwner } = ctx
  if (!isOwner) return reply('❌ Only owner can use this command!')

  const message = args.join(' ').trim()
  if (!message) return reply('❌ Provide a message to broadcast!\n_Example: .broadcast Hello everyone!_')

  await reply('📡 *Broadcasting message...*')

  try {
    // Get all chats
    const chats = await sock.groupFetchAllParticipating()
    const groupJids = Object.keys(chats)

    if (!groupJids.length) {
      return reply('❌ Bot is not in any groups!')
    }

    let success = 0
    let failed = 0

    for (const groupJid of groupJids) {
      try {
        await sock.sendMessage(groupJid, {
          text: `📢 *BROADCAST*\n━━━━━━━━━━━━━━━━━━━━━\n${message}\n━━━━━━━━━━━━━━━━━━━━━`
        })
        success++
        // Small delay to avoid spam detection
        await new Promise(r => setTimeout(r, 1000))
      } catch (_) {
        failed++
      }
    }

    await reply(`
━━━━━━━━━━━━━━━━━━━━━
📡 *BROADCAST COMPLETE*
━━━━━━━━━━━━━━━━━━━━━
✅ Sent: *${success}* groups
❌ Failed: *${failed}* groups
📊 Total: *${groupJids.length}* groups
━━━━━━━━━━━━━━━━━━━━━
`.trim())

  } catch (err) {
    await reply(`❌ Broadcast failed: ${err.message}`)
  }
}
