// ============================================================
//  VANGUARD MD — commands/owner.js
// ============================================================

const config = require('../config')
const defaults = require('../defaults')

module.exports = async (ctx) => {
  const { sock, jid, msg } = ctx
  const ownerNumber = config.ownerNumber || defaults.ownerNumber
  const botName = config.botName || defaults.botName

  if (!ownerNumber) {
    await ctx.reply('❌ Owner number is not set.')
    return
  }

  const vcard = `BEGIN:VCARD\nVERSION:3.0\nFN:${botName} Owner\nORG:${botName};\nTEL;type=CELL;type=VOICE;waid=${ownerNumber}:+${ownerNumber}\nEND:VCARD`

  await sock.sendMessage(jid, {
    contacts: {
      displayName: `${botName} Owner`,
      contacts: [{ vcard }]
    }
  }, { quoted: msg })

  await ctx.reply(`👑 *Owner Contact*\n📱 +${ownerNumber}\n\n_Tap the contact above to chat with the owner._`)
}
