// ============================================================
//  VANGUARD MD — commands/members.js
// ============================================================

module.exports = async (ctx) => {
  const { reply, sock, jid, fromGroup } = ctx

  if (!fromGroup) return reply('❌ This command can only be used in groups!')

  try {
    const meta = await sock.groupMetadata(jid)
    const all = meta.participants

    const list = all.map((p, i) => {
      const num = p.id.split('@')[0]
      const role = p.admin === 'superadmin' ? '👑' : p.admin === 'admin' ? '⭐' : '👤'
      return `${role} ${i + 1}. +${num}`
    }).join('\n')

    await reply(`
━━━━━━━━━━━━━━━━━━━━━
👥 *MEMBERS LIST*
━━━━━━━━━━━━━━━━━━━━━
📛 Group: *${meta.subject}*
👤 Total: *${all.length}*
━━━━━━━━━━━━━━━━━━━━━
${list}
━━━━━━━━━━━━━━━━━━━━━
👑 Owner  ⭐ Admin  👤 Member
━━━━━━━━━━━━━━━━━━━━━
`.trim())
  } catch (err) {
    await reply(`❌ Failed to fetch members: ${err.message}`)
  }
}
