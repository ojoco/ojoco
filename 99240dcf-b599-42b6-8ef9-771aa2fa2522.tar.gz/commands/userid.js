// ============================================================
//  VANGUARD MD — commands/userid.js
// ============================================================

const { jidToNum } = require('../lib/utils')

module.exports = async (ctx) => {
  const { reply, sender, jid, fromGroup } = ctx
  const num = jidToNum(sender)

  await reply(`
━━━━━━━━━━━━━━━━━━━━━
🪪 *YOUR ID INFO*
━━━━━━━━━━━━━━━━━━━━━
📱 Number: *+${num}*
🆔 JID: *${sender}*
💬 Chat: *${jid}*
👥 Type: *${fromGroup ? 'Group' : 'Private DM'}*
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}
