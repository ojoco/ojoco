// ============================================================
//  VANGUARD MD — commands/demote.js
// ============================================================

const { isBotAdmin, jidToNum } = require('../lib/utils')

module.exports = async (ctx) => {
  const { reply, sock, jid, fromGroup, sender, mentions, quoted, isSudo } = ctx

  if (!fromGroup) return reply('❌ This command can only be used in groups!')
  if (!isSudo) return reply('❌ Only sudo/owner can use this command!')

  const botAdmin = await isBotAdmin(sock, jid)
  if (!botAdmin) return reply('❌ I need to be an admin to demote members!')

  let target = mentions?.[0] || null
  if (!target && quoted?.sender) target = quoted.sender
  if (!target) return reply('❌ Mention or reply to someone to demote!\n_Example: .demote @user_')

  if (target === sender) return reply('❌ You cannot demote yourself!')

  const targetNum = jidToNum(target)

  try {
    await sock.groupParticipantsUpdate(jid, [target], 'demote')
    await reply({
      text: `
━━━━━━━━━━━━━━━━━━━━━
🔽 *DEMOTED*
━━━━━━━━━━━━━━━━━━━━━
📉 @${targetNum} has been removed from admins.
━━━━━━━━━━━━━━━━━━━━━
`.trim(),
      mentions: [target],
    })
  } catch (err) {
    await reply(`❌ Failed to demote: ${err.message}`)
  }
}
