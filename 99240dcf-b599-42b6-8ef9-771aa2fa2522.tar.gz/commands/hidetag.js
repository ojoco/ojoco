// ============================================================
//  VANGUARD MD — commands/hidetag.js
// ============================================================

module.exports = async (ctx) => {
  const { reply, sock, jid, fromGroup, args, isSudo } = ctx

  if (!fromGroup) return reply('❌ This command can only be used in groups!')
  if (!isSudo) return reply('❌ Only admins can use this command!')

  try {
    const meta = await sock.groupMetadata(jid)
    const all = meta.participants
    const mentions = all.map(p => p.id)
    const message = args.join(' ') || '📢 Message for all members'

    // Send message with all mentions hidden inside the text
    // The mentions are embedded but not visible as @tags in the message
    await sock.sendMessage(jid, {
      text: message,
      mentions,
    })
  } catch (err) {
    await reply(`❌ Failed to send hidetag: ${err.message}`)
  }
}
