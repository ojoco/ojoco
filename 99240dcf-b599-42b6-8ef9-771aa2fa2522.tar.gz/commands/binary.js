// ============================================================
//  VANGUARD MD — commands/binary.js
// ============================================================

module.exports = async (ctx) => {
  const { reply, args } = ctx

  if (!args.length) {
    return reply('❌ Provide text to convert!\n_Example: .binary Hello_')
  }

  const text = args.join(' ')

  // Check if input is already binary (decode)
  const isBinary = /^[01\s]+$/.test(text)

  if (isBinary && text.includes(' ')) {
    // Binary to text
    try {
      const decoded = text
        .trim()
        .split(' ')
        .map(bin => String.fromCharCode(parseInt(bin, 2)))
        .join('')

      await reply(`
🔢 *BINARY DECODE*
━━━━━━━━━━━━━━━━━━━━━
📥 Binary: _${text.length > 60 ? text.slice(0, 60) + '...' : text}_
━━━━━━━━━━━━━━━━━━━━━
📤 Text: *${decoded}*
━━━━━━━━━━━━━━━━━━━━━
`.trim())
    } catch {
      await reply('❌ Invalid binary string!')
    }
    return
  }

  // Text to binary
  if (text.length > 100) {
    return reply('❌ Text too long! Maximum 100 characters.')
  }

  const binary = text
    .split('')
    .map(char => char.charCodeAt(0).toString(2).padStart(8, '0'))
    .join(' ')

  await reply(`
🔢 *TEXT TO BINARY*
━━━━━━━━━━━━━━━━━━━━━
📥 Text: _${text}_
━━━━━━━━━━━━━━━━━━━━━
📤 Binary:
\`${binary}\`
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}
