// ============================================================
//  VANGUARD MD — commands/autorecord.js
// ============================================================

const config = require('../config')

module.exports = async (ctx) => {
  const { reply, args, isSudo, prefix } = ctx
  if (!isSudo) return reply('❌ Only sudo/owner can use this command!')

  const state = args[0]?.toLowerCase()
  if (!state || !['on', 'off'].includes(state)) {
    return reply(`❌ Usage: *.autorecord on/off*\n📍 Current: *${config.autoRecord ? 'ON' : 'OFF'}*`)
  }

  // ── Mutual exclusion checks ───────────────────────────────
  if (state === 'on') {
    if (config.autoType) {
      return reply(
        `━━━━━━━━━━━━━━━━━━━━━\n` +
        `⚠️ *CONFLICT DETECTED*\n` +
        `━━━━━━━━━━━━━━━━━━━━━\n` +
        `⌨️ *AutoType* is currently ON\n` +
        `Toggle it off first:\n` +
        `*${prefix}autotype off*\n` +
        `━━━━━━━━━━━━━━━━━━━━━`
      )
    }
    if (config.autoRecordType) {
      return reply(
        `━━━━━━━━━━━━━━━━━━━━━\n` +
        `⚠️ *CONFLICT DETECTED*\n` +
        `━━━━━━━━━━━━━━━━━━━━━\n` +
        `🔀 *AutoRecordType* is currently ON\n` +
        `Toggle it off first:\n` +
        `*${prefix}autorecordtype off*\n` +
        `━━━━━━━━━━━━━━━━━━━━━`
      )
    }
  }

  config.autoRecord = state === 'on'

  await reply(
    `━━━━━━━━━━━━━━━━━━━━━\n` +
    `🎙️ *AUTO RECORD*\n` +
    `━━━━━━━━━━━━━━━━━━━━━\n` +
    `${config.autoRecord
      ? '✅ *ON* — Bot will flex recording on every message 🎤'
      : '❌ *OFF* — Recording flex disabled'}\n` +
    `━━━━━━━━━━━━━━━━━━━━━`
  )
}
