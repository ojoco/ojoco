// ============================================================
//  VANGUARD MD — commands/ping2.js
// ============================================================

const os = require('os')
const { formatUptime, formatBytes } = require('../lib/utils')

module.exports = async (ctx) => {
  const { reply, sock, jid, msg } = ctx

  const start = Date.now()
  await sock.sendMessage(jid, { text: '📡 Fetching detailed info...' }, { quoted: msg })
  const ping = Date.now() - start

  const totalMem = os.totalmem()
  const freeMem = os.freemem()
  const usedMem = totalMem - freeMem
  const uptime = formatUptime(process.uptime())
  const cpus = os.cpus()
  const cpuModel = cpus[0]?.model || 'Unknown'
  const cpuCores = cpus.length

  await reply(`
━━━━━━━━━━━━━━━━━━━━━
📡 *VANGUARD MD — PING 2*
━━━━━━━━━━━━━━━━━━━━━
🏓 Ping: *${ping}ms*
⏱️ Uptime: *${uptime}*
━━━━━━━━━━━━━━━━━━━━━
💾 *Memory*
• Total: *${formatBytes(totalMem)}*
• Used:  *${formatBytes(usedMem)}*
• Free:  *${formatBytes(freeMem)}*
━━━━━━━━━━━━━━━━━━━━━
🖥️ *CPU*
• Model: *${cpuModel}*
• Cores: *${cpuCores}*
━━━━━━━━━━━━━━━━━━━━━
🟢 Bot is running smoothly!
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}
