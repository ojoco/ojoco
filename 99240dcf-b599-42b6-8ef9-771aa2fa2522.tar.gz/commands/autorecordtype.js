// ============================================================
//  VANGUARD MD — commands/autorecordtype.js
// ============================================================

const config = require('../config')

module.exports = async (ctx) => {
  const { reply, args, isSudo, prefix } = ctx
  if (!isSudo) return reply('❌ Only sudo/owner can use this command!')

  const state = args[0]?.toLowerCase()
  if (!state || !['on', 'off'].includes(state)) {
    return reply(`❌ Usage: *.autorecordtype on/off*\n📍 Current: *${config.autoRecordType ? 'ON' : 'OFF'}*`)
  }

  // ── Mutual exclusion checks ───────────────────────────────
  if (state === 'on') {
    if (config.autoType) {
      return reply(
        `━━━━━━━━━━━━━━━━━━━━━\n` +
        `⚠️ *CONFLICT DETECTED*\n` +
        `━━━━━━━━━━━━━━━━━━━━━\n` +
        `⌨️ *AutoType* is currently ON\n` +
        `Toggle both off first:\n` +
        `*${prefix}autotype off*\n` +
        `━━━━━━━━━━━━━━━━━━━━━`
      )
    }
    if (config.autoRecord) {
      return reply(
        `━━━━━━━━━━━━━━━━━━━━━\n` +
        `⚠️ *CONFLICT DETECTED*\n` +
        `━━━━━━━━━━━━━━━━━━━━━\n` +
        `🎙️ *AutoRecord* is currently ON\n` +
        `Toggle it off first:\n` +
        `*${prefix}autorecord off*\n` +
        `━━━━━━━━━━━━━━━━━━━━━`
      )
    }
  }

  config.autoRecordType = state === 'on'

  await reply(
    `━━━━━━━━━━━━━━━━━━━━━\n` +
    `🔀 *AUTO RECORD TYPE*\n` +
    `━━━━━━━━━━━━━━━━━━━━━\n` +
    `${config.autoRecordType
      ? '✅ *ON* — Bot randomly mixes typing + recording flex 🎭\n_7s total: random split each time_'
      : '❌ *OFF* — Mixed presence flex disabled'}\n` +
    `━━━━━━━━━━━━━━━━━━━━━`
  )
}
