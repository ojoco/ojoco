// ============================================================
//  VANGUARD MD — commands/listban.js
// ============================================================

const fs = require('fs')
const path = require('path')

const BAN_FILE = path.join(__dirname, '..', 'data', 'banned.json')

const getBanned = () => {
  try {
    if (!fs.existsSync(BAN_FILE)) return []
    return JSON.parse(fs.readFileSync(BAN_FILE, 'utf8'))
  } catch { return [] }
}

module.exports = async (ctx) => {
  const { reply, isOwner } = ctx
  if (!isOwner) return reply('❌ Only owner can use this command!')

  const banned = getBanned()

  if (!banned.length) {
    return reply('✅ No users are currently banned!')
  }

  const list = banned.map((num, i) => `${i + 1}. +${num}`).join('\n')

  await reply(`
━━━━━━━━━━━━━━━━━━━━━
🔨 *BANNED USERS*
━━━━━━━━━━━━━━━━━━━━━
Total: *${banned.length}*
━━━━━━━━━━━━━━━━━━━━━
${list}
━━━━━━━━━━━━━━━━━━━━━
💡 Use *.unban @user* to unban
💡 Use *.unbanall* to clear all
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}
