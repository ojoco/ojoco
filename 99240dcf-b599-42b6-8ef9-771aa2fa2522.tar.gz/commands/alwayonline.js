// ============================================================
//  VANGUARD MD — commands/alwaysonline.js
// ============================================================

const config = require('../config')

module.exports = async (ctx) => {
  const { reply, args, isSudo, sock } = ctx
  if (!isSudo) return reply('❌ Only sudo/owner can use this command!')

  const state = args[0]?.toLowerCase()
  if (!state || !['on', 'off'].includes(state)) {
    return reply(`❌ Usage: *.alwaysonline on/off*\n📍 Current: *${config.alwaysOnline ? 'ON' : 'OFF'}*`)
  }

  config.alwaysOnline = state === 'on'

  // ── Instantly apply presence change ──────────────────────
  if (config.alwaysOnline) {
    try { await sock.sendPresenceUpdate('available') } catch (_) {}
  } else {
    // Release to WA servers — real last seen resumes immediately
    try { await sock.sendPresenceUpdate('unavailable') } catch (_) {}
  }

  await reply(`
━━━━━━━━━━━━━━━━━━━━━
🟢 *ALWAYS ONLINE*
━━━━━━━━━━━━━━━━━━━━━
${config.alwaysOnline
  ? '✅ *ON* — Account will always appear online 24/7'
  : '❌ *OFF* — Real last seen restored\n_WA will now show your actual activity_'}
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}
