// ============================================================
//  VANGUARD MD — commands/link.js
// ============================================================

const { isBotAdmin } = require('../lib/utils')

module.exports = async (ctx) => {
  const { reply, sock, jid, fromGroup, isSudo } = ctx

  if (!fromGroup) return reply('❌ This command can only be used in groups!')
  if (!isSudo) return reply('❌ Only sudo/owner can use this command!')

  const botAdmin = await isBotAdmin(sock, jid)
  if (!botAdmin) return reply('❌ I need to be an admin to get the invite link!')

  try {
    const code = await sock.groupInviteCode(jid)
    const link = `https://chat.whatsapp.com/${code}`
    const meta = await sock.groupMetadata(jid)

    await reply(`
━━━━━━━━━━━━━━━━━━━━━
🔗 *GROUP INVITE LINK*
━━━━━━━━━━━━━━━━━━━━━
📛 Group: *${meta.subject}*
━━━━━━━━━━━━━━━━━━━━━
🔗 ${link}
━━━━━━━━━━━━━━━━━━━━━
⚠️ _Share carefully — anyone with this link can join!_
━━━━━━━━━━━━━━━━━━━━━
`.trim())
  } catch (err) {
    await reply(`❌ Failed to get invite link: ${err.message}`)
  }
}
