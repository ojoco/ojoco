// ============================================================
//  VANGUARD MD — commands/upload.js
//  Upload any media and return a public URL
// ============================================================

const fs   = require('fs')
const path = require('path')
const { tmpdir } = require('os')
const { downloadContentFromMessage } = require('@whiskeysockets/baileys')
const { TelegraPh, UploadFileUgu } = require('../lib/uploader')

// ── Download any media type to buffer ────────────────────────
const getMediaBuffer = async (m) => {
  if (!m) return null

  const types = [
    { key: 'imageMessage',    type: 'image',    ext: '.jpg'  },
    { key: 'videoMessage',    type: 'video',    ext: '.mp4'  },
    { key: 'audioMessage',    type: 'audio',    ext: '.mp3'  },
    { key: 'stickerMessage',  type: 'sticker',  ext: '.webp' },
    { key: 'documentMessage', type: 'document', ext: null    },
  ]

  for (const { key, type, ext } of types) {
    if (!m[key]) continue
    const stream = await downloadContentFromMessage(m[key], type)
    const chunks = []
    for await (const chunk of stream) chunks.push(chunk)
    const finalExt = ext || path.extname(m[key]?.fileName || '') || '.bin'
    return { buffer: Buffer.concat(chunks), ext: finalExt }
  }

  return null
}

module.exports = async (ctx) => {
  const { sock, msg, jid, quoted, reply } = ctx

  // ── Try current message first, then quoted ────────────────
  let media = await getMediaBuffer(msg.message)
  if (!media && quoted?.message) media = await getMediaBuffer(quoted.message)

  if (!media) return reply(
    '❌ Send or reply to a media file to get a URL!\n' +
    '_Supports: image, video, audio, sticker, document_'
  )

  await reply('⏳ *Uploading...*')

  const ts       = Date.now()
  const tempPath = path.join(tmpdir(), `vanguard_upload_${ts}${media.ext}`)

  try {
    fs.writeFileSync(tempPath, media.buffer)

    let url = ''
    const isImage = ['.jpg', '.jpeg', '.png', '.webp'].includes(media.ext)

    if (isImage) {
      // TelegraPh for images — fast and permanent
      try {
        url = await TelegraPh(tempPath)
      } catch (_) {
        // Fallback to Uguu
        const res = await UploadFileUgu(tempPath)
        url = typeof res === 'string' ? res : (res.url || res.url_full || '')
      }
    } else {
      // Uguu for everything else
      const res = await UploadFileUgu(tempPath)
      url = typeof res === 'string' ? res : (res.url || res.url_full || '')
    }

    if (!url) return reply('❌ Upload failed — no URL returned.')

    await reply(
      '🔗 *Upload Complete!*\n' +
      '━━━━━━━━━━━━━━━━━━━━━\n' +
      url
    )

  } catch (err) {
    await reply('❌ Upload failed: ' + err.message)
  } finally {
    try { fs.unlinkSync(tempPath) } catch (_) {}
  }
}
