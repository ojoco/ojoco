// ============================================================
//  VANGUARD MD — commands/dare.js
// ============================================================

const { readData, randItem } = require('../lib/utils')

module.exports = async (ctx) => {
  const { reply, sender } = ctx
  const dares = readData('dares.json')
  if (!dares.length) return reply('❌ No dares found!')
  const { dare } = randItem(dares)
  await reply(`🔥 *Truth or Dare — DARE*\n\n@${sender.split('@')[0]}, you must:\n\n💪 _${dare}_`)
}
