// ============================================================
//  VANGUARD MD — commands/unbanall.js
// ============================================================

const fs = require('fs')
const path = require('path')

const BAN_FILE = path.join(__dirname, '..', 'data', 'banned.json')

module.exports = async (ctx) => {
  const { reply, isOwner } = ctx
  if (!isOwner) return reply('❌ Only owner can use this command!')

  try {
    const before = fs.existsSync(BAN_FILE)
      ? JSON.parse(fs.readFileSync(BAN_FILE, 'utf8')).length
      : 0

    fs.writeFileSync(BAN_FILE, JSON.stringify([], null, 2))

    await reply(`
━━━━━━━━━━━━━━━━━━━━━
✅ *ALL USERS UNBANNED*
━━━━━━━━━━━━━━━━━━━━━
🔓 Removed *${before}* user(s) from ban list.
✅ Bot will now respond to everyone.
━━━━━━━━━━━━━━━━━━━━━
`.trim())
  } catch (err) {
    await reply(`❌ Failed to clear ban list: ${err.message}`)
  }
}
