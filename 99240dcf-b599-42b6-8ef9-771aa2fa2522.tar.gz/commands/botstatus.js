// ============================================================
//  VANGUARD MD — commands/botstatus.js
// ============================================================

const config = require('../config')
const defaults = require('../defaults')

const tog = (val) => val ? '✅ ON' : '❌ OFF'

module.exports = async (ctx) => {
  const { reply } = ctx
  const prefix = config.prefix || defaults.prefix

  // ── Presence mode label ───────────────────────────────────
  const presenceMode = () => {
    if (config.autoRecordType ?? defaults.autoRecordType) return '🔀 AutoRecordType'
    if (config.autoRecord     ?? defaults.autoRecord)     return '🎙️ AutoRecord'
    if (config.autoType       ?? defaults.autoType)       return '⌨️ AutoType'
    return '❌ OFF'
  }

  await reply(`
━━━━━━━━━━━━━━━━━━━━━
⚙️ *BOT STATUS*
━━━━━━━━━━━━━━━━━━━━━
🤖 Name: *${config.botName || defaults.botName}*
📡 Mode: *${(config.mode || defaults.mode).toUpperCase()}*
🔑 Prefix: *${prefix}*
━━━━━━━━━━━━━━━━━━━━━
⚙️ *Auto Features*
• Auto Read:          ${tog(config.autoRead         ?? defaults.autoRead)}
• Always Online:      ${tog(config.alwaysOnline     ?? defaults.alwaysOnline)}
• Auto View Status:   ${tog(config.autoViewStatus   ?? defaults.autoViewStatus)}
• Auto React Status:  ${tog(config.autoReactStatus  ?? defaults.autoReactStatus)}
• Chatbot:            ${tog(config.chatbot           ?? defaults.chatbot)}
• Anti Call:          ${tog(config.anticall          ?? defaults.anticall)}
━━━━━━━━━━━━━━━━━━━━━
🎭 *Presence Flex*
• Auto Type:          ${tog(config.autoType         ?? defaults.autoType)}
• Auto Record:        ${tog(config.autoRecord       ?? defaults.autoRecord)}
• AutoRecordType:     ${tog(config.autoRecordType   ?? defaults.autoRecordType)}
• Active Mode:        ${presenceMode()}
━━━━━━━━━━━━━━━━━━━━━
🛡️ *Privacy Features*
• Anti Delete:        ${tog(config.antidelete        ?? defaults.antidelete)}
• Anti Delete Status: ${tog(config.antideleteStatus  ?? defaults.antideleteStatus)}
• Anti Edit:          ${tog(config.antiedit          ?? defaults.antiedit)}
━━━━━━━━━━━━━━━━━━━━━
😀 Status Emojis: *${(config.statusEmojis || defaults.statusEmojis).join(' ')}*
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}
