// ============================================================
//  VANGUARD MD — commands/daily.js
// ============================================================

const { getBalance, setBalance, getEconomy, saveEconomy, jidToNum } = require('../lib/utils')
const config = require('../config')
const defaults = require('../defaults')

module.exports = async (ctx) => {
  const { reply, sender } = ctx
  const senderNum = jidToNum(sender)

  const data = getEconomy()
  const account = getBalance(senderNum)
  const now = Date.now()
  const cooldown = 24 * 60 * 60 * 1000 // 24 hours

  if (account.lastDaily) {
    const elapsed = now - account.lastDaily
    if (elapsed < cooldown) {
      const remaining = cooldown - elapsed
      const hrs = Math.floor(remaining / 3600000)
      const mins = Math.floor((remaining % 3600000) / 60000)
      const secs = Math.floor((remaining % 60000) / 1000)
      return reply(`
⏳ *Daily Already Claimed!*
━━━━━━━━━━━━━━━━━━━━━
⏰ Come back in: *${hrs}h ${mins}m ${secs}s*
━━━━━━━━━━━━━━━━━━━━━
`.trim())
    }
  }

  const reward = config.dailyReward || defaults.dailyReward
  const newBalance = account.balance + reward

  // Update
  if (!data[senderNum]) data[senderNum] = {}
  data[senderNum].balance = newBalance
  data[senderNum].lastDaily = now
  saveEconomy(data)

  await reply({
    text: `
━━━━━━━━━━━━━━━━━━━━━
🎁 *DAILY REWARD*
━━━━━━━━━━━━━━━━━━━━━
👤 @${senderNum}
━━━━━━━━━━━━━━━━━━━━━
✅ Claimed: *+$${reward.toLocaleString()}*
💵 New Balance: *$${newBalance.toLocaleString()}*
━━━━━━━━━━━━━━━━━━━━━
⏰ Come back in *24 hours* for more!
━━━━━━━━━━━━━━━━━━━━━
`.trim(),
    mentions: [sender],
  })
}
