// ============================================================
//  VANGUARD MD — commands/status.js
// ============================================================

const os = require('os')
const { formatBytes, formatUptime } = require('../lib/utils')

module.exports = async (ctx) => {
  const { reply } = ctx

  const platform = os.platform()
  const release = os.release()
  const arch = os.arch()
  const hostname = os.hostname()
  const totalMem = os.totalmem()
  const freeMem = os.freemem()
  const usedMem = totalMem - freeMem
  const memPercent = ((usedMem / totalMem) * 100).toFixed(1)
  const uptime = formatUptime(os.uptime())
  const botUptime = formatUptime(process.uptime())
  const nodeVersion = process.version
  const cpus = os.cpus()
  const cpuModel = cpus[0]?.model || 'Unknown'

  await reply(`
━━━━━━━━━━━━━━━━━━━━━
📊 *SYSTEM STATUS*
━━━━━━━━━━━━━━━━━━━━━
🖥️ *OS Info*
• Platform: *${platform}*
• Release: *${release}*
• Arch: *${arch}*
• Hostname: *${hostname}*
━━━━━━━━━━━━━━━━━━━━━
💾 *Memory*
• Total: *${formatBytes(totalMem)}*
• Used:  *${formatBytes(usedMem)}* (${memPercent}%)
• Free:  *${formatBytes(freeMem)}*
━━━━━━━━━━━━━━━━━━━━━
🖥️ *CPU*
• ${cpuModel}
• Cores: *${cpus.length}*
━━━━━━━━━━━━━━━━━━━━━
⏱️ *Uptime*
• System: *${uptime}*
• Bot: *${botUptime}*
━━━━━━━━━━━━━━━━━━━━━
🟢 Node.js: *${nodeVersion}*
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}
