// ============================================================
//  VANGUARD MD — commands/autoread.js
// ============================================================

const config = require('../config')

module.exports = async (ctx) => {
  const { reply, args, isSudo } = ctx
  if (!isSudo) return reply('❌ Only sudo/owner can use this command!')

  const state = args[0]?.toLowerCase()
  if (!state || !['on', 'off'].includes(state)) {
    return reply(`❌ Usage: *.autoread on/off*\n📍 Current: *${config.autoRead ? 'ON' : 'OFF'}*`)
  }

  config.autoRead = state === 'on'

  await reply(`
━━━━━━━━━━━━━━━━━━━━━
👁️ *AUTO READ*
━━━━━━━━━━━━━━━━━━━━━
${config.autoRead ? '✅ ON — Messages will be marked as read automatically' : '❌ OFF — Messages will not be auto-read'}
━━━━━━━━━━━━━━━━━━━━━
`.trim())
}
