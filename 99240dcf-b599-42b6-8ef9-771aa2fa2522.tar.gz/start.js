// ============================================================
//  VANGUARD MD — start.js
//  Auto-installer + Launcher
//  Set this as your main entry point on the panel
// ============================================================

const { execSync, spawn } = require('child_process')
const fs = require('fs')
const path = require('path')

// ── Console colors without chalk (not installed yet) ─────────
const c = {
  green:  (s) => `\x1b[32m${s}\x1b[0m`,
  yellow: (s) => `\x1b[33m${s}\x1b[0m`,
  red:    (s) => `\x1b[31m${s}\x1b[0m`,
  cyan:   (s) => `\x1b[36m${s}\x1b[0m`,
  bold:   (s) => `\x1b[1m${s}\x1b[0m`,
}

const log = (msg) => console.log(c.cyan(`[VANGUARD MD] `) + msg)
const success = (msg) => console.log(c.green(`[✅ DONE] `) + msg)
const warn = (msg) => console.log(c.yellow(`[⚠️  WARN] `) + msg)
const error = (msg) => console.log(c.red(`[❌ ERROR] `) + msg)

// ── Banner ────────────────────────────────────────────────────
console.log(c.green(c.bold(`
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   🤖  VANGUARD MD — Auto Installer
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`)))

// ── Check if node_modules exists ─────────────────────────────
const nodeModulesPath = path.join(__dirname, 'node_modules')
const packageJsonPath = path.join(__dirname, 'package.json')

if (!fs.existsSync(packageJsonPath)) {
  error('package.json not found! Cannot install dependencies.')
  process.exit(1)
}

// ── Check if baileys is already installed ─────────────────────
const baileysPath = path.join(nodeModulesPath, '@whiskeysockets', 'baileys')
const alreadyInstalled = fs.existsSync(baileysPath)

if (alreadyInstalled) {
  success('Dependencies already installed!')
  log('Skipping npm install...')
  launchBot()
} else {
  log('Dependencies not found. Installing now...')
  log('This may take 1-2 minutes on first run...')
  installDependencies()
}

// ── Install dependencies ──────────────────────────────────────
function installDependencies() {
  try {
    log('Running npm install --legacy-peer-deps...')
    console.log(c.yellow('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'))

    execSync('npm install --legacy-peer-deps', {  // ← ONLY CHANGE
      stdio: 'inherit',
      cwd: __dirname,
    })

    console.log(c.yellow('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━'))
    success('All dependencies installed successfully!')
    launchBot()

  } catch (err) {
    error(`npm install failed: ${err.message}`)
    error('Please check your package.json and try again.')
    process.exit(1)
  }
}

// ── Launch index.js ───────────────────────────────────────────
function launchBot() {
  log('Handing off to index.js...')
  console.log(c.green(c.bold(`
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   🚀  Launching VANGUARD MD...
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`)))

  const bot = spawn(process.execPath, [path.join(__dirname, 'index.js')], {
    stdio: 'inherit',
    cwd: __dirname,
    env: process.env,
  })

  bot.on('close', (code) => {
    if (code !== 0) {
      error(`Bot exited with code ${code}`)
    }
    process.exit(code ?? 0)
  })

  bot.on('error', (err) => {
    error(`Failed to launch index.js: ${err.message}`)
    process.exit(1)
  })
}

// ── Graceful exit passthrough ─────────────────────────────────
process.on('SIGINT', () => process.exit(0))
process.on('SIGTERM', () => process.exit(0))
