// ============================================================
//  VANGUARD MD — commands/toimage.js
//  Converts STATIC stickers only → jpg image
// ============================================================

const fs = require('fs')
const path = require('path')
const ffmpeg = require('fluent-ffmpeg')
const ffmpegStatic = require('ffmpeg-static')
const { tmpdir } = require('os')
const { downloadMediaMessage } = require('@whiskeysockets/baileys')

ffmpeg.setFfmpegPath(ffmpegStatic)

const convertToImage = (inputPath, outputPath) => {
  return new Promise((resolve, reject) => {
    ffmpeg(inputPath)
      .outputOptions([
        '-vframes', '1',
        '-f', 'image2',
      ])
      .toFormat('mjpeg')
      .save(outputPath)
      .on('end', resolve)
      .on('error', reject)
  })
}

module.exports = async (ctx) => {
  const { sock, msg, jid, quoted, reply } = ctx

  const target = quoted || msg
  const msgType = Object.keys(target.message || {})[0]
  const isSticker = msgType === 'stickerMessage'

  if (!isSticker) {
    return reply('❌ Please reply to a *sticker* to convert to image!\n_Usage: .toimage (reply to static sticker)_')
  }

  const isAnimated = target.message.stickerMessage?.isAnimated

  if (isAnimated) {
    return reply('❌ This is an *animated sticker*!\n_Use *.tovideo* to convert animated stickers._')
  }

  await reply('⏳ *Converting sticker to image...*')

  try {
    const buffer = await downloadMediaMessage(
      { message: target.message, key: target.key },
      'buffer',
      {},
      { logger: require('pino')({ level: 'silent' }), reuploadRequest: sock.updateMediaMessage }
    )

    const inputPath  = path.join(tmpdir(), `vanguard_sticker_${Date.now()}.webp`)
    const outputPath = path.join(tmpdir(), `vanguard_image_${Date.now()}.jpg`)

    fs.writeFileSync(inputPath, buffer)
    await convertToImage(inputPath, outputPath)

    const imageBuffer = fs.readFileSync(outputPath)

    await sock.sendMessage(jid, {
      image: imageBuffer,
      mimetype: 'image/jpeg',
      caption: '🖼️ *Sticker converted to image*',
    }, { quoted: msg })

    fs.unlinkSync(inputPath)
    fs.unlinkSync(outputPath)

  } catch (err) {
    await reply(`❌ Failed to convert sticker: ${err.message}`)
  }
}
