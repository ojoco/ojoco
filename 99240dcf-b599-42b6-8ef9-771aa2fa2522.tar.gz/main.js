// ============================================================
//  VANGUARD MD — main.js
//  Message Handler | Mode Shield | Status Parser | Routing
// ============================================================

const path = require('path')
const fs = require('fs')
const config = require('./config')
const defaults = require('./defaults')
const logger = require('./lib/logger')
const { saveMessage, saveStatus, saveViewOnce } = require('./lib/messageStore')
const { handleGroupEvents } = require('./lib/groupEvents')

// ── Preload enforcers ─────────────────────────────────────────
const { enforce: enforceLink }    = require('./commands/antilink')
const { enforce: enforceSticker } = require('./commands/antisticker')
const { enforce: enforceMedia }   = require('./commands/antimedia')
const { enforce: enforceBadword } = require('./commands/antibadword')
const { enforceCard: enforceGroupMentionCard, recentJoins } = require('./commands/antigroupmention')

// ── Cooldown Store ────────────────────────────────────────────
const cooldowns = new Map()
const COOLDOWN_MS = 5000

// ── Push name cache — realJid → display name ─────────────────
const nameCache = new Map()

// ── Strip :XX device suffix from JID ─────────────────────────
const stripDevice = (jid) => {
  if (!jid) return null
  return jid.replace(/:[0-9]+@/, '@')
}

// ── Check if JID is a @lid internal device ID ────────────────
const isLid = (jid) => Boolean(jid?.endsWith('@lid'))

// ── Resolve @lid → real @s.whatsapp.net JID ──────────────────
const resolveRealJid = async (sock, rawJid, chatJid) => {
  if (!rawJid) return null
  const stripped = stripDevice(rawJid)
  if (stripped.endsWith('@s.whatsapp.net')) return stripped
  if (isLid(stripped) && chatJid && isGroup(chatJid)) {
    try {
      const meta = await sock.groupMetadata(chatJid)
      const match = meta.participants.find(p => {
        const pLid = stripDevice(p.lid || '')
        const pId  = stripDevice(p.id  || '')
        return pLid === stripped || pId === stripped
      })
      if (match?.id) return stripDevice(match.id)
    } catch (_) {}
  }
  if (isLid(stripped)) return null
  return stripped
}

// ── Cache push name — real JIDs only ─────────────────────────
const cacheName = (jid, name) => {
  if (!jid || !name) return
  const clean = stripDevice(jid)
  if (clean && !isLid(clean)) nameCache.set(clean, name)
}

// ── Resolve a person for display ─────────────────────────────
const resolvePerson = async (sock, rawJid, chatJid, storedPushName = null) => {
  if (!rawJid) {
    return { name: storedPushName || null, realJid: null, num: null }
  }

  const stripped = stripDevice(rawJid)
  let realJid = await resolveRealJid(sock, stripped, chatJid)
  let name = realJid ? nameCache.get(realJid) : null

  if (!name && chatJid && isGroup(chatJid)) {
    try {
      const meta = await sock.groupMetadata(chatJid)
      const match = meta.participants.find(p => {
        const pId  = stripDevice(p.id  || '')
        const pLid = stripDevice(p.lid || '')
        return pId === (realJid || stripped) || pLid === stripped
      })
      if (match) {
        if (!realJid && match.id) realJid = stripDevice(match.id)
        name = match.notify || match.name || null
        if (name && realJid) cacheName(realJid, name)
      }
    } catch (_) {}
  }

  if (!name && storedPushName) name = storedPushName

  const num = realJid?.replace('@s.whatsapp.net', '') || null
  return { name, realJid, num }
}

// ── Format person line for alerts ────────────────────────────
const personLine = (person) => {
  if (person.name && person.num) return `*${person.name}* @${person.num}`
  if (person.num)                return `@${person.num}`
  if (person.name)               return `*${person.name}*`
  return `_unknown_`
}

// ── Presence Flex — fires instantly, non-blocking ────────────
const runPresenceFlex = (sock, jid) => {
  if (config.autoRecordType ?? defaults.autoRecordType) {
    setImmediate(async () => {
      try {
        const totalMs    = 7000
        const firstMs    = Math.floor(Math.random() * 5000) + 1000
        const secondMs   = totalMs - firstMs
        const firstType  = Math.random() < 0.5 ? 'recording' : 'composing'
        const secondType = firstType === 'recording' ? 'composing' : 'recording'
        await sock.sendPresenceUpdate(firstType, jid)
        await new Promise(r => setTimeout(r, firstMs))
        await sock.sendPresenceUpdate(secondType, jid)
        await new Promise(r => setTimeout(r, secondMs))
        await sock.sendPresenceUpdate('paused', jid)
      } catch (_) {}
    })
    return
  }

  if (config.autoRecord ?? defaults.autoRecord) {
    setImmediate(async () => {
      try {
        await sock.sendPresenceUpdate('recording', jid)
        await new Promise(r => setTimeout(r, 5000))
        await sock.sendPresenceUpdate('paused', jid)
      } catch (_) {}
    })
    return
  }

  if (config.autoType ?? defaults.autoType) {
    setImmediate(async () => {
      try {
        await sock.sendPresenceUpdate('composing', jid)
        await new Promise(r => setTimeout(r, 5000))
        await sock.sendPresenceUpdate('paused', jid)
      } catch (_) {}
    })
  }
}

// ── Check if prefix is in no-prefix sigma mode 🗿 ────────────
const isNoPrefixMode = () => {
  const p = config.prefix || defaults.prefix || '.'
  return p === 'none' || p === ''
}

// ── Helpers ───────────────────────────────────────────────────
const isOwner = (jid) => {
  const owner = config.ownerNumber || defaults.ownerNumber
  if (!owner) return false
  const clean = jid
    .replace(/:[0-9]+@/, '@')
    .replace('@s.whatsapp.net', '')
    .replace('@g.us', '')
    .trim()
  return clean === owner.trim()
}

const isSudo = (jid) => {
  const sudos = config.sudoNumbers || defaults.sudoNumbers || []
  const clean = jid
    .replace(/:[0-9]+@/, '@')
    .replace('@s.whatsapp.net', '')
    .replace('@g.us', '')
    .trim()
  return clean === (config.ownerNumber || defaults.ownerNumber)?.trim() ||
    sudos.includes(clean)
}

const isBanned = (jid) => {
  try {
    const banPath = path.join(__dirname, 'data', 'banned.json')
    if (!fs.existsSync(banPath)) return false
    const banned = JSON.parse(fs.readFileSync(banPath, 'utf8'))
    const clean = jid
      .replace(/:[0-9]+@/, '@')
      .replace('@s.whatsapp.net', '')
      .replace('@g.us', '')
      .trim()
    return banned.includes(clean)
  } catch { return false }
}

const getPrefix = () => config.prefix || defaults.prefix || '.'

const isGroup = (jid) => jid.endsWith('@g.us')

const getGroupSettings = (groupId) => {
  try {
    const dir = path.join(__dirname, 'groupstore', groupId)
    const file = path.join(dir, 'groupsettings.json')
    if (!fs.existsSync(file)) return {}
    return JSON.parse(fs.readFileSync(file, 'utf8'))
  } catch { return {} }
}

const getBody = (msg) => {
  const m = msg.message
  if (!m) return ''
  return (
    m.conversation ||
    m.extendedTextMessage?.text ||
    m.imageMessage?.caption ||
    m.videoMessage?.caption ||
    m.buttonsResponseMessage?.selectedButtonId ||
    m.listResponseMessage?.singleSelectReply?.selectedRowId ||
    ''
  )
}

const getMsgType = (msg) => {
  const m = msg.message
  if (!m) return 'unknown'
  const keys = Object.keys(m)
  return keys[0] || 'unknown'
}

const getQuoted = (msg) => {
  const m = msg.message
  if (!m) return null
  const ext = m.extendedTextMessage
  if (ext?.contextInfo?.quotedMessage) {
    return {
      message:  ext.contextInfo.quotedMessage,
      sender:   ext.contextInfo.participant || ext.contextInfo.remoteJid,
      stanzaId: ext.contextInfo.stanzaId,
    }
  }
  for (const key of Object.keys(m)) {
    const val = m[key]
    if (val?.contextInfo?.quotedMessage) {
      return {
        message:  val.contextInfo.quotedMessage,
        sender:   val.contextInfo.participant || val.contextInfo.remoteJid,
        stanzaId: val.contextInfo.stanzaId,
      }
    }
  }
  return null
}

const getMentions = (msg) => {
  const m = msg.message
  if (!m) return []
  for (const key of Object.keys(m)) {
    const mentions = m[key]?.contextInfo?.mentionedJid
    if (mentions?.length) return mentions
  }
  return []
}

// ── isViewOnce — all Baileys 7.x formats ─────────────────────
const isViewOnce = (msg) => {
  const m = msg.message
  if (!m) return false
  if (m.viewOnceMessage || m.viewOnceMessageV2 || m.viewOnceMessageV2Extension) return true
  if (m.imageMessage?.viewOnce) return true
  if (m.videoMessage?.viewOnce)  return true
  return false
}

const getViewOnceContent = (msg) => {
  const m = msg.message
  if (!m) return null
  if (m.viewOnceMessage?.message)            return m.viewOnceMessage.message
  if (m.viewOnceMessageV2?.message)          return m.viewOnceMessageV2.message
  if (m.viewOnceMessageV2Extension?.message) return m.viewOnceMessageV2Extension.message
  if (m.imageMessage?.viewOnce) return m
  if (m.videoMessage?.viewOnce)  return m
  return null
}

const isQuotedViewOnce = (quotedMessage) => {
  if (!quotedMessage) return false
  if (
    quotedMessage.viewOnceMessage ||
    quotedMessage.viewOnceMessageV2 ||
    quotedMessage.viewOnceMessageV2Extension
  ) return true
  if (quotedMessage.imageMessage?.viewOnce) return true
  if (quotedMessage.videoMessage?.viewOnce)  return true
  return false
}

// ── sendReply — instant, zero presence delay ─────────────────
const sendReply = async (sock, jid, content, quoted = null) => {
  try {
    const options = quoted ? { quoted } : {}
    await sock.sendMessage(jid, content, options)
  } catch (err) {
    logger.error(`❌ Send error: ${err.message}`)
  }
}

const resolveGroupName = async (sock, jid) => {
  try {
    const meta = await sock.groupMetadata(jid)
    return meta.subject || jid
  } catch (_) { return jid }
}

// ── Main Export ───────────────────────────────────────────────
module.exports = async (sock, commands) => {

  // ── Always Online / Real Last Seen ────────────────────────
  if (config.alwaysOnline ?? defaults.alwaysOnline) {
    setInterval(async () => {
      try { await sock.sendPresenceUpdate('available') } catch (_) {}
    }, 10000)
  } else {
    try { await sock.sendPresenceUpdate('unavailable') } catch (_) {}
  }

  sock.ev.on('presence.update', ({ id, presences }) => {
    for (const [jid, presence] of Object.entries(presences)) {
      logger.debug(`👁️  ${jid} in ${id}: ${presence.lastKnownPresence}`)
    }
  })

  sock.ev.on('group-participants.update', async (update) => {
    // ── Track joins/adds → prevents stub 27 false positives ──
    // FIX: Use digits-only normalization to match toPhoneNum() in antigroupmention.js
    // Old code left @domain attached in some cases → keys never matched recentJoins
    if (update.action === 'add' || update.action === 'invite') {
      for (const p of (update.participants || [])) {
        const participant = typeof p === 'string' ? p : (p.id || p.jid || '')
        if (!participant) continue
        const num = participant
          .replace(/:[0-9]+@/, '@')  // strip :device suffix
          .replace(/@.*/, '')         // strip @domain entirely
          .replace(/[^0-9]/g, '')     // digits only — matches toPhoneNum() 🗿
          .trim()
        if (num) {
          recentJoins.set(num, Date.now())
          logger.info(`📢 recentJoins: tracked ${num} for 30s`)
        }
      }
    }
    await handleGroupEvents(sock, update)
  })

  // ── Message Updates (antidelete / antiedit) ───────────────
  sock.ev.on('messages.update', async (updates) => {
    for (const update of updates) {
      try {

        // ── Deleted message ─────────────────────────────────
        if (update.update?.messageStubType === 1 || update.update?.message === null) {
          if (!(config.antidelete ?? defaults.antidelete)) continue
          const stored = saveMessage.getStored(update.key.id)
          if (!stored) continue

          const ownerJid = (config.ownerNumber || defaults.ownerNumber) + '@s.whatsapp.net'
          const chat     = update.key.remoteJid

          const sender  = await resolvePerson(sock, stored.sender, chat, stored.pushName)
          const deleter = await resolvePerson(
            sock,
            update.key.participant || update.key.remoteJid,
            chat,
            null
          )

          const chatName      = isGroup(chat) ? await resolveGroupName(sock, chat) : 'DM'
          const deletedBySelf = sender.realJid && deleter.realJid
            ? sender.realJid === deleter.realJid
            : (sender.num && sender.num === deleter.num)
          const deletedByLine = deletedBySelf
            ? `_deleted their own message_`
            : `_deleted by ${personLine(deleter)}_`
          const mediaLabel = stored.mediaType
            ? `\n🎞️ Type: *${stored.mediaType}${stored.ptt ? ' (voice note)' : ''}*`
            : ''

          const alertText =
            `🗑️ *Deleted Message Alert*\n` +
            `━━━━━━━━━━━━━━━━━━━━━\n` +
            `👤 ${personLine(sender)}\n` +
            `🗑️ ${personLine(deleter)}\n` +
            `💬 Chat: *${chatName}*\n` +
            `${deletedByLine}` +
            `${mediaLabel}\n` +
            `━━━━━━━━━━━━━━━━━━━━━\n` +
            `${stored.body ? `📝 *Message:*\n${stored.body}` : '_[No text content]_'}`

          const alertMsg = await sock.sendMessage(ownerJid, {
            text: alertText,
            mentions: [sender.realJid, deleter.realJid].filter(Boolean),
          })

          if (stored.mediaPath && fs.existsSync(stored.mediaPath)) {
            try {
              const mediaBuffer  = fs.readFileSync(stored.mediaPath)
              const mediaPayload = {
                [stored.mediaType]: mediaBuffer,
                caption: stored.caption || undefined,
              }
              if (stored.mediaType === 'document') {
                mediaPayload.mimetype = stored.mimetype || 'application/octet-stream'
                mediaPayload.fileName = stored.fileName
                  || `recovered${stored.mediaPath.match(/\.[^.]+$/)?.[0] || '.bin'}`
              }
              if (stored.mediaType === 'audio') {
                mediaPayload.mimetype = stored.mimetype || 'audio/ogg; codecs=opus'
                mediaPayload.ptt      = stored.ptt ?? false
              }
              await sock.sendMessage(ownerJid, mediaPayload, { quoted: alertMsg })
            } catch (mediaErr) {
              logger.error(`🗑️ Media recovery error: ${mediaErr.message}`)
            }
          }
        }

        // ── Edited message ──────────────────────────────────
        if (update.update?.message?.protocolMessage?.type === 14) {
          if (!(config.antiedit ?? defaults.antiedit)) continue
          const stored = saveMessage.getStored(update.key.id)
          if (!stored) continue

          const ownerJid = (config.ownerNumber || defaults.ownerNumber) + '@s.whatsapp.net'
          const chat     = update.key.remoteJid
          const editor   = await resolvePerson(
            sock,
            update.key.participant || update.key.remoteJid,
            chat,
            stored.pushName
          )
          const chatName = isGroup(chat) ? await resolveGroupName(sock, chat) : 'DM'

          await sock.sendMessage(ownerJid, {
            text:
              `✏️ *Edited Message Alert*\n` +
              `━━━━━━━━━━━━━━━━━━━━━\n` +
              `👤 ${personLine(editor)}\n` +
              `💬 Chat: *${chatName}*\n` +
              `━━━━━━━━━━━━━━━━━━━━━\n` +
              `📝 *Original message:*\n${stored.body || '_[No text]_'}`,
            mentions: [editor.realJid].filter(Boolean),
          })
        }

      } catch (err) {
        logger.error(`❌ Message update error: ${err.message}`)
      }
    }
  })

  // ── Messages Upsert ───────────────────────────────────────
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    for (const msg of messages) {
      try {
        const jid = msg.key.remoteJid

        // ── Status broadcast ──────────────────────────────────
        if (jid === 'status@broadcast') {
          const sender    = msg.key.participant || msg.key.remoteJid
          const timestamp = msg.messageTimestamp
          if (msg.pushName) cacheName(sender, msg.pushName)
          if (config.autoViewStatus ?? defaults.autoViewStatus) {
            try { await sock.readMessages([msg.key]) } catch (_) {}
          }
          if (config.autoReactStatus ?? defaults.autoReactStatus) {
            try {
              const emojis = config.statusEmojis || defaults.statusEmojis || ['💙', '💚']
              const emoji  = emojis[Math.floor(Math.random() * emojis.length)]
              await sock.sendMessage(sender, { react: { text: emoji, key: msg.key } })
            } catch (_) {}
          }
          await saveStatus(msg, sender, timestamp)
          continue
        }

        // ── Anti group mention — BEFORE notify gate ───────────
        if (isGroup(jid)) {
          if (msg.messageStubType || msg.message?.groupStatusMentionMessage) {
            logger.info(
              `🔬 GROUP MSG | type: ${type} | stubType: ${msg.messageStubType || 'none'} | ` +
              `keys: ${Object.keys(msg.message || {}).join(',') || 'none'} | ` +
              `params: ${JSON.stringify(msg.messageStubParameters || [])}`
            )
          }
          try { await enforceGroupMentionCard(sock, msg, jid) } catch (_) {}
        }

        if (type !== 'notify') continue

        // ── Extract sender ───────────────────────────────────
        let sender
        if (msg.key.fromMe) {
          const botJid = sock.user?.id || ''
          sender = botJid.replace(/:[0-9]+/, '')
          if (!sender.includes('@')) sender += '@s.whatsapp.net'
        } else {
          sender = msg.key.participant || msg.key.remoteJid
        }

        // ── Cache push name immediately ──────────────────────
        if (msg.pushName && sender && !isLid(stripDevice(sender))) {
          cacheName(sender, msg.pushName)
        }

        const fromMe    = msg.key.fromMe
        const fromGroup = isGroup(jid)

        // ── Instant presence flex ────────────────────────────
        if (!fromMe) runPresenceFlex(sock, jid)

        const senderNum = sender
          .replace(/:[0-9]+@/, '@')
          .replace('@s.whatsapp.net', '')
          .replace('@g.us', '')
          .trim()

        const body     = getBody(msg)
        const msgType  = getMsgType(msg)
        const quoted   = getQuoted(msg)
        const mentions = getMentions(msg)

        // ── Emoji VO Trigger — BEFORE fromMe skip ───────────
        if (fromMe && isOwner(sender) && quoted && isQuotedViewOnce(quoted.message)) {
          const trimmedBody   = body.trim()
          const triggerEmojis = ['😂','😭','❤️','🥰','😳','🙌','🥲','😍','🔥','💀','😤','🤣']
          const chars         = [...trimmedBody]

          const isAllSameEmoji = (
            chars.length >= 1 &&
            chars.length <= 3 &&
            triggerEmojis.includes(chars[0]) &&
            chars.every(c => c === chars[0])
          )

          logger.info(`🔍 EMOJI CHECK | chars: ${JSON.stringify(chars)} | len: ${chars.length} | match: ${isAllSameEmoji}`)

          if (isAllSameEmoji) {
            try {
              const vvCommand = commands['vv2'] || commands['vv']
              if (vvCommand) {
                await vvCommand({
                  sock, msg, jid, sender, senderNum, quoted,
                  command: 'vv2', args: [], body: trimmedBody,
                  fromGroup, fromMe, isOwner: true, isSudo: true,
                  groupSettings: {}, prefix: getPrefix(),
                  reply:            () => {},
                  sendMsg:          (c) => sock.sendMessage(jid, c),
                  simulatePresence: () => {},
                  react:            (e) => sock.sendMessage(jid, { react: { text: e, key: msg.key } }),
                })
              }
            } catch (err) {
              logger.error(`👁️ Emoji VO trigger error: ${err.message}`)
            }
            continue
          }
        }

        // ── fromMe skip ──────────────────────────────────────
        if (fromMe) {
          const noPrefix = isNoPrefixMode()
          if (!noPrefix && !body.startsWith(getPrefix())) continue
          if (noPrefix) {
            const firstWord = body.trim().split(/\s+/)[0]?.toLowerCase()
            if (!firstWord || !commands[firstWord]) continue
          }
        }

        // ── Auto Read ────────────────────────────────────────
        if (config.autoRead ?? defaults.autoRead) {
          try { await sock.readMessages([msg.key]) } catch (_) {}
        }

        // ── Save message ─────────────────────────────────────
        await saveMessage(msg, sender, jid)
        if (isViewOnce(msg)) await saveViewOnce(msg, sender, jid)

        if (isBanned(sender)) continue

        // ── Mode Shield ──────────────────────────────────────
        const mode = config.mode || defaults.mode
        if (mode === 'private' && !isSudo(sender) && !fromMe) continue

        // ── Group enforcers ──────────────────────────────────
        if (fromGroup && !isSudo(sender) && !fromMe) {
          try { await enforceLink(sock, msg, jid, sender) }    catch (_) {}
          try { await enforceSticker(sock, msg, jid, sender) } catch (_) {}
          try { await enforceMedia(sock, msg, jid, sender) }   catch (_) {}
          try { await enforceBadword(sock, msg, jid, sender) } catch (_) {}
        }

        // ── Chatbot ──────────────────────────────────────────
        if (config.chatbot ?? defaults.chatbot) {
          const noPrefix = isNoPrefixMode()
          const isKnownCommand = noPrefix
            ? Boolean(commands[body.trim().split(/\s+/)[0]?.toLowerCase()])
            : body.startsWith(getPrefix())
          if (!isKnownCommand) {
            try {
              const chatbotData = JSON.parse(
                fs.readFileSync(path.join(__dirname, 'data', 'chatbot.json'), 'utf8')
              )
              const lowerBody = body.toLowerCase().trim()
              const chatReply = chatbotData[lowerBody]
              if (chatReply) {
                await sendReply(sock, jid, { text: chatReply }, msg)
                continue
              }
            } catch (_) {}
          }
        }

        // ── Command Parsing — normal + sigma mode 🗿 ─────────
        const prefix   = getPrefix()
        const noPrefix = isNoPrefixMode()

        if (!noPrefix && !body.startsWith(prefix)) continue

        const rawArgs = noPrefix
          ? body.trim().split(/\s+/)
          : body.slice(prefix.length).trim().split(/\s+/)

        const args    = [...rawArgs]
        const command = args.shift().toLowerCase()

        // ── Cooldown ─────────────────────────────────────────
        if (!isOwner(sender)) {
          const coolKey  = `${senderNum}:${command}`
          const lastUsed = cooldowns.get(coolKey) || 0
          const now      = Date.now()
          if (now - lastUsed < COOLDOWN_MS) {
            const remaining = ((COOLDOWN_MS - (now - lastUsed)) / 1000).toFixed(1)
            try {
              await sock.sendMessage(jid, {
                text: `⏳ Please wait *${remaining}s* before using this command again.`
              }, { quoted: msg })
            } catch (_) {}
            continue
          }
          cooldowns.set(coolKey, now)
        }

        const groupSettings = fromGroup ? getGroupSettings(jid) : {}

        // ── Build context ────────────────────────────────────
        const ctx = {
          sock, msg, jid, sender, senderNum,
          args, body, command, quoted, mentions,
          fromGroup, fromMe,
          isOwner: isOwner(sender),
          isSudo:  isSudo(sender),
          groupSettings,
          prefix,
          reply:            (content) => sendReply(sock, jid, typeof content === 'string' ? { text: content } : content, msg),
          sendMsg:          (content) => sock.sendMessage(jid, content),
          simulatePresence: () => {},
          react:            (emoji)   => sock.sendMessage(jid, { react: { text: emoji, key: msg.key } }),
        }

        logger.cmd(`📨 [${fromGroup ? 'GROUP' : 'DM'}] ${senderNum} → ${noPrefix ? '' : prefix}${command} ${args.join(' ')}`)

        // ── Route to plugin — instant ────────────────────────
        if (commands[command]) {
          try {
            await commands[command](ctx)
          } catch (err) {
            logger.error(`❌ Command error [${command}]: ${err.message}`)
            await ctx.reply(`❌ *Error running command:* ${command}\n_${err.message}_`)
          }
        }

      } catch (err) {
        logger.error(`💥 Message processing error: ${err.message}`)
      }
    }
  })

  logger.success('✅ VANGUARD MD main handler active')
}
